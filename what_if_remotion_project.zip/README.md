# WHAT IF? — Episode 01

A 20-second cinematic Remotion animation: "What if all men disappeared, except you and your best friend?"

## Run in GitHub Codespaces (Android-friendly)

1. Create a new **public or private** GitHub repository.
2. Upload the files in this project, keeping the `src` folder structure.
3. Open the repository in Codespaces.
4. In the terminal, run:

```bash
npm install
npm run start
```

5. Remotion Studio opens a preview. Select `WhatIfMenDisappeared`.

## Render MP4

In the Codespaces terminal:

```bash
npm run render
```

The finished video is saved as `out/video.mp4`.

To download it on Android, open the `out` folder in the Codespaces file explorer, tap `video.mp4`, then choose Download.

## Specs

- 1920 × 1080
- 30 FPS
- 600 frames / 20 seconds
- React + Remotion
- No external image assets required

This is an original procedural motion-graphics starter project. It uses stylized shapes and gradients rather than photorealistic 3D footage.
