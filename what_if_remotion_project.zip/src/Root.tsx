import React from "react";
import { Composition } from "remotion";
import { WhatIfVideo } from "./WhatIfVideo";

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="WhatIfMenDisappeared"
      component={WhatIfVideo}
      durationInFrames={600}
      fps={30}
      width={1920}
      height={1080}
    />
  );
};