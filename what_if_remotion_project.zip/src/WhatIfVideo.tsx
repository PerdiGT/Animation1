import React from "react";
import {
  AbsoluteFill,
  interpolate,
  Sequence,
  spring,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";

const C = {
  bg: "#050914",
  blue: "#071b35",
  cyan: "#72d9ff",
  orange: "#ff9b5a",
  white: "#f4f7fb",
  muted: "#9eafc5",
};

const clamp = { extrapolateLeft: "clamp" as const, extrapolateRight: "clamp" as const };

const Fade: React.FC<{children: React.ReactNode; start?: number; end?: number}> = ({children, start=0, end=24}) => {
  const f = useCurrentFrame();
  const opacity = interpolate(f, [start, end], [0, 1], clamp);
  return <AbsoluteFill style={{opacity}}>{children}</AbsoluteFill>;
};

const Grain: React.FC = () => {
  const f = useCurrentFrame();
  return <AbsoluteFill style={{
    pointerEvents: "none", opacity: 0.12,
    backgroundImage: "radial-gradient(rgba(255,255,255,.55) .7px, transparent .8px)",
    backgroundSize: "5px 5px",
    transform: `translate(${(f % 7) - 3}px, ${(f % 5) - 2}px)`,
    mixBlendMode: "soft-light"
  }} />;
};

const Vignette: React.FC = () => <AbsoluteFill style={{
  background: "radial-gradient(ellipse at center, transparent 35%, rgba(0,0,0,.72) 100%)",
  pointerEvents: "none"
}} />;

const Title: React.FC<{eyebrow: string; headline: string; sub?: string; accent?: string}> = ({eyebrow, headline, sub, accent=C.cyan}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const y = spring({frame: f, fps, config: {damping: 18, stiffness: 90, mass: 0.8}});
  return <div style={{
    position: "absolute", left: 150, right: 150, bottom: 145,
    transform: `translateY(${interpolate(y,[0,1],[55,0])}px)`,
    opacity: interpolate(f,[0,14],[0,1],clamp),
    fontFamily: "Arial, Helvetica, sans-serif", color: C.white
  }}>
    <div style={{fontSize: 22, letterSpacing: 8, fontWeight: 700, color: accent, marginBottom: 22}}>{eyebrow}</div>
    <div style={{fontSize: 82, lineHeight: 0.98, letterSpacing: -3, fontWeight: 900, textTransform: "uppercase", maxWidth: 1500}}>{headline}</div>
    {sub && <div style={{fontSize: 27, color: C.muted, marginTop: 24, letterSpacing: 1}}>{sub}</div>}
  </div>;
};

const Stars: React.FC = () => {
  const f = useCurrentFrame();
  return <svg width="100%" height="100%" viewBox="0 0 1920 1080" style={{position:"absolute"}}>
    {Array.from({length:100}, (_,i) => {
      const x = (i*197+43)%1920;
      const y = (i*113+29)%1080;
      const r = i%9===0 ? 2.2 : 1.1;
      const twinkle = 0.25 + 0.65*((Math.sin(f*0.06+i)+1)/2);
      return <circle key={i} cx={x} cy={y} r={r} fill="#d9efff" opacity={twinkle}/>;
    })}
  </svg>;
};

const Earth: React.FC = () => {
  const f = useCurrentFrame();
  const scale = interpolate(f,[0,120],[0.82,1.08],clamp);
  return <AbsoluteFill style={{justifyContent:"center",alignItems:"center",background:"radial-gradient(ellipse at 50% 46%, #12385d 0%, #071426 42%, #03060d 100%)"}}>
    <Stars/>
    <div style={{
      width: 510, height: 510, borderRadius: "50%", transform:`scale(${scale}) rotate(${f*0.12}deg)`,
      background: "radial-gradient(circle at 34% 28%, #4f9ac0 0%, #145078 32%, #071c3d 67%, #020713 100%)",
      boxShadow: "0 0 75px 18px rgba(75,177,255,.28), inset -45px -20px 65px rgba(0,0,0,.75)",
      position:"relative", overflow:"hidden", border:"2px solid rgba(140,220,255,.45)"
    }}>
      <div style={{position:"absolute",inset:-30,background:"repeating-linear-gradient(115deg, transparent 0px, transparent 54px, rgba(125,210,190,.2) 57px, transparent 88px)",filter:"blur(8px)"}}/>
      <div style={{position:"absolute",inset:0,background:"linear-gradient(90deg, transparent 35%, rgba(0,0,0,.78) 100%)"}}/>
    </div>
    <div style={{position:"absolute",top:130,fontSize:20,letterSpacing:9,color:"#8ab9d8",fontWeight:700}}>GLOBAL EVENT // 00:00 UTC</div>
    <Title eyebrow="A WORLDWIDE ANOMALY" headline="12:00 AM. THE WORLD CHANGED." sub="One impossible moment. Eight billion lives interrupted."/>
  </AbsoluteFill>;
};

const City: React.FC = () => {
  const f = useCurrentFrame();
  const lights = interpolate(f,[0,25],[1,0.15],clamp);
  const buildings = [
    [0,480,170,440],[145,390,210,530],[330,520,145,400],[455,330,230,590],
    [665,450,170,470],[825,280,230,640],[1050,410,190,510],[1230,350,230,570],
    [1460,465,180,455],[1630,320,290,600]
  ];
  return <AbsoluteFill style={{background:"linear-gradient(180deg,#101e32 0%,#172c43 45%,#070d17 100%)"}}>
    <div style={{position:"absolute",top:110,left:0,right:0,height:430,background:"radial-gradient(ellipse at 50% 90%,rgba(255,157,95,.22),transparent 65%)"}}/>
    {buildings.map(([x,y,w,h],i)=><div key={i} style={{position:"absolute",left:x,top:y,width:w,height:h,background:`linear-gradient(90deg,#08111e,#17283a ${50+i%3*8}%,#07101c)`,border:"1px solid rgba(130,180,220,.12)",boxShadow:"0 0 35px rgba(0,0,0,.35)"}}>
      {Array.from({length:Math.floor(h/38)*2},(_,j)=><span key={j} style={{position:"absolute",left:12+(j%2)*((w-35)/2),top:18+Math.floor(j/2)*38,width:12,height:17,background:`rgba(255,190,120,${lights*(0.25+(j%4)*.12)})`,boxShadow:"0 0 9px rgba(255,160,90,.3)"}}/>)}
    </div>)}
    <div style={{position:"absolute",left:0,right:0,bottom:0,height:260,background:"linear-gradient(180deg,transparent,#03070d 75%)"}}/>
    <div style={{position:"absolute",left:0,right:0,bottom:185,height:2,background:"rgba(150,190,220,.18)"}}/>
    <div style={{position:"absolute",left:"42%",bottom:0,width:300,height:390,background:"linear-gradient(90deg,#03070d,#111e2c,#03070d)",clipPath:"polygon(42% 0,58% 0,100% 100%,0 100%)",opacity:.8}}/>
    <div style={{position:"absolute",top:115,left:140,fontSize:20,letterSpacing:7,color:C.orange,fontWeight:700}}>EMERGENCY BROADCAST</div>
    <Title eyebrow="NO ANSWERS. NO GOODBYE." headline="THE STREETS WENT SILENT." sub="Everywhere. All at once. No explanation." accent={C.orange}/>
  </AbsoluteFill>;
};

const Survivors: React.FC = () => {
  const f = useCurrentFrame();
  const rise = spring({frame:f,fps:30,config:{damping:16,stiffness:75}});
  const person = (left:number, delay:number, scale:number) => <div style={{
    position:"absolute",left, bottom:105, width:130,height:360,
    transform:`translateY(${interpolate(rise,[0,1],[150+delay,0])}px) scale(${scale})`,
    transformOrigin:"bottom center", filter:"drop-shadow(0 0 28px rgba(75,160,220,.18))"
  }}>
    <div style={{position:"absolute",left:37,top:0,width:57,height:65,borderRadius:"48% 48% 42% 42%",background:"#050a12",boxShadow:"inset 0 0 12px #26384c"}}/>
    <div style={{position:"absolute",left:15,top:59,width:100,height:180,borderRadius:"42% 42% 8% 8%",background:"linear-gradient(90deg,#050a11,#172638 50%,#030810)"}}/>
    <div style={{position:"absolute",left:18,top:220,width:42,height:140,background:"#050a11",transform:"skew(-4deg)"}}/>
    <div style={{position:"absolute",left:70,top:220,width:42,height:140,background:"#050a11",transform:"skew(4deg)"}}/>
  </div>;
  return <AbsoluteFill style={{background:"radial-gradient(ellipse at 50% 50%,#1b3c57 0%,#0a1727 48%,#03070d 100%)"}}>
    <Stars/>
    <div style={{position:"absolute",left:0,right:0,bottom:0,height:300,background:"linear-gradient(180deg,transparent,#02060b)"}}/>
    {person(790,15,1)}
    {person(1010,0,.92)}
    <div style={{position:"absolute",top:130,left:0,right:0,textAlign:"center",fontSize:21,letterSpacing:8,color:C.cyan,fontWeight:700}}>EXCEPTIONS DETECTED</div>
    <Title eyebrow="TWO REMAIN" headline="BUT WE WERE STILL HERE." sub="You. Your best friend. And a question no one could answer."/>
  </AbsoluteFill>;
};

const Explore: React.FC = () => {
  const f = useCurrentFrame();
  const shift = interpolate(f,[0,150],[-35,35],clamp);
  return <AbsoluteFill style={{background:"linear-gradient(120deg,#07111d,#172b3e 55%,#080e19)"}}>
    <div style={{position:"absolute",inset:0,background:"radial-gradient(ellipse at 75% 30%,rgba(255,145,83,.22),transparent 40%)"}}/>
    <div style={{position:"absolute",left:-100+shift,top:170,width:1200,height:650,transform:"perspective(700px) rotateX(58deg)",background:"repeating-linear-gradient(90deg,transparent 0 118px,rgba(150,190,220,.12) 120px 122px),repeating-linear-gradient(0deg,#101e2c 0 90px,#1a2d40 92px 94px)",opacity:.65}}/>
    <div style={{position:"absolute",left:0,right:0,bottom:0,height:260,background:"linear-gradient(180deg,transparent,#03070c)"}}/>
    <div style={{position:"absolute",top:150,left:150,fontSize:22,color:C.muted,letterSpacing:4}}>DAY 01 // UNKNOWN CITY</div>
    <Title eyebrow="A NEW REALITY" headline="THE WORLD WAS OURS TO QUESTION." sub="But why were we the only ones left?"/>
  </AbsoluteFill>;
};

const Cliffhanger: React.FC = () => {
  const f = useCurrentFrame();
  const pulse = 0.75 + 0.25*Math.sin(f*.12);
  return <AbsoluteFill style={{background:"#020409",justifyContent:"center",alignItems:"center"}}>
    <div style={{position:"absolute",width:850,height:500,borderRadius:"50%",background:"radial-gradient(ellipse,rgba(55,130,190,.18),transparent 70%)",transform:`scale(${pulse})`}}/>
    <div style={{fontFamily:"Arial, sans-serif",fontSize:25,letterSpacing:10,color:C.orange,marginBottom:35}}>TO BE CONTINUED</div>
    <div style={{fontFamily:"Arial, sans-serif",fontSize:92,fontWeight:900,letterSpacing:-3,color:C.white,textAlign:"center",lineHeight:1.05,maxWidth:1450,opacity:interpolate(f,[0,20],[0,1],clamp),transform:`translateY(${interpolate(f,[0,20],[35,0],clamp)}px)`}}>WHY WERE WE<br/>STILL HERE?</div>
    <div style={{position:"absolute",bottom:105,fontFamily:"Arial, sans-serif",fontSize:18,letterSpacing:6,color:"#65788e"}}>WHAT IF?  /  EPISODE 01</div>
  </AbsoluteFill>;
};

export const WhatIfVideo: React.FC = () => {
  return <AbsoluteFill style={{background:C.bg}}>
    <Sequence from={0} durationInFrames={120}><Fade><Earth/></Fade></Sequence>
    <Sequence from={120} durationInFrames={120}><Fade><City/></Fade></Sequence>
    <Sequence from={240} durationInFrames={120}><Fade><Survivors/></Fade></Sequence>
    <Sequence from={360} durationInFrames={150}><Fade><Explore/></Fade></Sequence>
    <Sequence from={510} durationInFrames={90}><Fade><Cliffhanger/></Fade></Sequence>
    <Vignette/>
    <Grain/>
  </AbsoluteFill>;
};