# WHAT IF? — Cartoon Storytelling Edition

A vertical 2D cartoon storytelling Remotion project inspired by the supplied reference:
- 1080 × 1920 portrait
- 30 FPS
- 60 seconds (1800 frames)
- Flat vector-style cartoon characters, city, car interior, map UI, missing-person card
- Top HUD labels and large kinetic captions with yellow emphasis
- Procedural visuals; no external image assets required

## Run
```bash
npm install
npm run start
```

## Render
```bash
npm run render
```
Output: `out/video.mp4`

This is a stylized vector-cartoon prototype. Character and scene art is drawn with SVG/CSS; it is not frame-by-frame hand-drawn animation or photorealistic footage.
