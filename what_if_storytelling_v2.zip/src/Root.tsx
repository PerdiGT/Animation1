import React from "react";
import {Composition} from "remotion";
import {WhatIfStory} from "./WhatIfStory";

export const RemotionRoot: React.FC = () => <Composition
  id="WhatIfStory"
  component={WhatIfStory}
  durationInFrames={1800}
  fps={30}
  width={1080}
  height={1920}
/>;