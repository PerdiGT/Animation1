import React from "react";
import {
  AbsoluteFill, interpolate, Sequence, spring, useCurrentFrame, useVideoConfig
} from "remotion";

const W=1080, H=1920;
const clamp={extrapolateLeft:"clamp" as const,extrapolateRight:"clamp" as const};
const colors={bg:"#080b18",panel:"#11172b",yellow:"#ffd84d",white:"#fff8ee",blue:"#547de8",pink:"#ef6384",muted:"#aab4d0"};

const Txt:React.FC<{children:React.ReactNode;size?:number;color?:string;weight?:number;style?:React.CSSProperties}> =
({children,size=44,color=colors.white,weight=800,style={}})=><div style={{fontFamily:"Arial, sans-serif",fontSize:size,color,fontWeight:weight,...style}}>{children}</div>;

const Hud:React.FC<{part:string;route:string;time:string}> = ({part,route,time}) => (
  <div style={{position:"absolute",top:55,left:55,right:55,display:"flex",justifyContent:"space-between",alignItems:"center",zIndex:20}}>
    <div style={{border:"2px solid #725e2e",borderRadius:10,padding:"12px 18px",background:"#101326",color:colors.yellow,fontFamily:"monospace",fontSize:22,letterSpacing:2}}> {part} </div>
    <div style={{border:"2px solid #725e2e",borderRadius:10,padding:"12px 18px",background:"#101326",color:colors.yellow,fontFamily:"monospace",fontSize:22}}> {route} · {time} </div>
  </div>
);

const Subtitle:React.FC<{a:string;b?:string;accent?:string}> = ({a,b,accent=colors.yellow}) => {
  const f=useCurrentFrame(); const {fps}=useVideoConfig();
  const s=spring({frame:f,fps,config:{damping:16,stiffness:130}});
  return <div style={{position:"absolute",left:65,right:65,bottom:245,minHeight:145,display:"flex",alignItems:"center",justifyContent:"center",textAlign:"center",zIndex:30,transform:`translateY(${interpolate(s,[0,1],[35,0])}px)`,opacity:interpolate(f,[0,8],[0,1],clamp)}}>
    <div style={{fontFamily:"Arial,sans-serif",fontSize:57,lineHeight:1.13,fontWeight:900,letterSpacing:-1,textShadow:"0 4px 4px #000, 0 0 18px #000",color:colors.white}}>
      {a} {b&&<span style={{color:accent}}>{b}</span>}
    </div>
  </div>;
};

const Backdrop:React.FC<{night?:boolean}> = ({night=true}) => <AbsoluteFill style={{background:night?"linear-gradient(180deg,#11152d,#202b49 55%,#080c19)":"linear-gradient(180deg,#d88d6b,#f2bd8c 48%,#344b5b)"}}>
  {Array.from({length:12},(_,i)=><div key={i} style={{position:"absolute",left:i*105-20,top:280+(i%3)*45,width:75+(i%3)*18,height:520+(i%4)*65,background:i%2?"#151b35":"#202541",borderRadius:"8px 8px 0 0",opacity:.9}}>
    {Array.from({length:18},(_,j)=><div key={j} style={{position:"absolute",left:12+(j%3)*19,top:20+Math.floor(j/3)*27,width:8,height:12,background:(i+j)%4===0?"#ffd57a":"#35405d",opacity:.8}}/>)}
  </div>)}
  <div style={{position:"absolute",bottom:0,left:0,right:0,height:650,background:"linear-gradient(180deg,transparent,#070a14 80%)"}}/>
</AbsoluteFill>;

const Person:React.FC<{x:number;y:number;hood?:boolean;hair?:string;shirt?:string;expression?:"normal"|"shock"|"sad";scale?:number}> =
({x,y,hood=false,hair="#33251f",shirt="#4263bd",expression="normal",scale=1}) => (
  <g transform={`translate(${x} ${y}) scale(${scale})`}>
    {hood&&<circle cx="0" cy="-110" r="116" fill="#243b78" stroke="#617ed2" strokeWidth="18"/>}
    <path d="M-84 0 Q-100 60 -112 190 L112 190 Q100 60 84 0Z" fill={shirt}/>
    <path d="M-65 -170 Q-70 -255 0 -250 Q80 -250 70 -165 L68 -90 Q0 -45 -68 -90Z" fill={hair}/>
    <ellipse cx="0" cy="-115" rx="76" ry="91" fill="#f0bd9c"/>
    {!hood&&<path d="M-76 -155 Q-65 -260 25 -238 Q90 -218 77 -135 Q35 -183 -5 -170 Q-43 -150 -76 -155" fill={hair}/>}
    {expression==="shock"?<>
      <ellipse cx="-28" cy="-122" rx="11" ry="17" fill="#241c22"/><ellipse cx="28" cy="-122" rx="11" ry="17" fill="#241c22"/>
      <ellipse cx="0" cy="-78" rx="15" ry="21" fill="#8d3f45"/>
    </>:<>
      <path d="M-43 -130 q14 -13 28 0 M15 -130 q14 -13 28 0" stroke="#30252b" strokeWidth="8" fill="none" strokeLinecap="round"/>
      <circle cx="-28" cy="-113" r="7" fill="#241c22"/><circle cx="28" cy="-113" r="7" fill="#241c22"/>
      <path d={expression==="sad"?"M-22 -72 Q0 -92 22 -72":"M-22 -78 Q0 -58 22 -78"} stroke="#8e4b4b" strokeWidth="7" fill="none" strokeLinecap="round"/>
    </>}
    <circle cx="-55" cy="-75" r="13" fill="#ee9e91" opacity=".55"/><circle cx="55" cy="-75" r="13" fill="#ee9e91" opacity=".55"/>
  </g>
);

const CarInterior:React.FC<{frame:number}> = ({frame}) => <AbsoluteFill style={{background:"radial-gradient(ellipse at 50% 38%,#26385a,#090d1a 70%)"}}>
  <div style={{position:"absolute",left:40,right:40,top:250,height:720,borderRadius:"48% 48% 12% 12%",background:"linear-gradient(180deg,#121a2c,#070a12)",border:"18px solid #30364b",boxShadow:"inset 0 0 45px #000"}}/>
  <div style={{position:"absolute",left:100,right:100,top:320,height:480,background:"linear-gradient(180deg,#17264b,#080e20)",borderRadius:"45% 45% 4% 4%",overflow:"hidden"}}>
    {Array.from({length:9},(_,i)=><div key={i} style={{position:"absolute",left:i*125,top:30+(i%3)*30,width:75,height:360,background:"#0b1429",opacity:.9}}/>)}
    <div style={{position:"absolute",right:90,top:70,width:100,height:100,borderRadius:"50%",background:"#dce2ff",opacity:.8,boxShadow:"0 0 50px #b6c7ff"}}/>
  </div>
  <svg viewBox={`0 0 ${W} ${H}`} style={{position:"absolute",inset:0,width:"100%",height:"100%"}}>
    <Person x={365} y={1020} hood hair="#263b74" shirt="#4167c5" expression={frame>270?"shock":"normal"} scale={1.18}/>
    <Person x={720} y={1020} hair="#38241e" shirt="#40533e" expression={frame>310?"shock":"normal"} scale={1.18}/>
  </svg>
  <div style={{position:"absolute",left:0,right:0,bottom:0,height:500,background:"linear-gradient(180deg,transparent,#05070e 35%,#151a29)"}}/>
  <div style={{position:"absolute",left:0,right:0,bottom:290,height:18,background:"#31394e",boxShadow:"0 0 30px #000"}}/>
</AbsoluteFill>;

const MapScene:React.FC = () => {
  const f=useCurrentFrame();
  const dash=-(f*5)%80;
  return <AbsoluteFill style={{background:"#071326"}}>
    <div style={{position:"absolute",inset:0,backgroundImage:"linear-gradient(rgba(48,72,112,.24) 2px,transparent 2px),linear-gradient(90deg,rgba(48,72,112,.24) 2px,transparent 2px)",backgroundSize:"82px 82px"}}/>
    <svg viewBox="0 0 1080 1920" style={{position:"absolute",inset:0,width:"100%",height:"100%"}}>
      <path d="M170 1450 C320 1300 270 1080 490 980 S710 760 850 510" stroke="#f4c84b" strokeWidth="9" fill="none" strokeDasharray="18 18" strokeDashoffset={dash}/>
      <circle cx="170" cy="1450" r="30" fill="#ffb64a"/><circle cx="850" cy="510" r="30" fill="#72e4ff"/>
      <circle cx="170" cy="1450" r="58" stroke="#ffb64a" strokeWidth="4" fill="none" opacity=".5"/>
      <circle cx="850" cy="510" r="58" stroke="#72e4ff" strokeWidth="4" fill="none" opacity=".5"/>
    </svg>
    <div style={{position:"absolute",top:440,left:120,right:120,textAlign:"center",color:"#dce9ff",fontFamily:"Arial",fontSize:35,fontWeight:800,letterSpacing:6}}>LAST KNOWN LOCATION</div>
    <div style={{position:"absolute",top:560,left:120,right:120,textAlign:"center",color:colors.yellow,fontFamily:"Arial",fontSize:70,fontWeight:900}}>60 KM</div>
  </AbsoluteFill>;
};

const WantedCard:React.FC = () => <AbsoluteFill style={{background:"#11142b",justifyContent:"center",alignItems:"center"}}>
  <div style={{width:760,background:"#e7e8ef",borderRadius:24,overflow:"hidden",boxShadow:"0 20px 80px #000"}}>
    <div style={{background:"#e84b67",padding:28,textAlign:"center",fontFamily:"Arial",fontSize:76,fontWeight:900,color:"white",letterSpacing:8}}>MISSING</div>
    <div style={{height:570,margin:45,background:"linear-gradient(180deg,#cbd2e2,#9da9c3)",display:"flex",alignItems:"center",justifyContent:"center"}}>
      <svg viewBox="0 0 300 400" width="280"><Person x={150} y={330} hair="#263b74" shirt="#4566ad" scale={1.15}/></svg>
    </div>
    <div style={{textAlign:"center",fontFamily:"Arial",fontSize:44,fontWeight:900,color:"#171a2b",paddingBottom:20}}>PERDI · 14 YEARS OLD</div>
    <div style={{textAlign:"center",fontFamily:"Arial",fontSize:30,color:"#45495a",paddingBottom:35}}>LAST SEEN: UNKNOWN</div>
  </div>
</AbsoluteFill>;

const SceneIntro:React.FC=()=> <AbsoluteFill><Backdrop/><Hud part="WHAT IF? / 01" route="WORLDWIDE" time="00:00"/><div style={{position:"absolute",top:500,left:80,right:80,textAlign:"center"}}><Txt size={33} color={colors.yellow}>AN IMPOSSIBLE QUESTION</Txt><Txt size={88} style={{lineHeight:1.02,marginTop:30}}>WHAT IF ALL MEN</Txt><Txt size={88} color={colors.yellow} style={{lineHeight:1.02}}>DISAPPEARED?</Txt></div><Subtitle a="AT MIDNIGHT," b="THE WORLD CHANGED."/></AbsoluteFill>;
const SceneEvent:React.FC=()=> <AbsoluteFill><Backdrop/><Hud part="PART 01" route="GLOBAL ALERT" time="00:12"/><div style={{position:"absolute",top:430,left:80,right:80,background:"#11172b",border:"3px solid #ef536c",padding:45,borderRadius:20,textAlign:"center"}}><Txt size={30} color="#ff687e">BREAKING NEWS</Txt><Txt size={72} style={{marginTop:24,lineHeight:1.1}}>MILLIONS<br/>MISSING</Txt><Txt size={28} color={colors.muted} style={{marginTop:30}}>Authorities report a worldwide disappearance.</Txt></div><Subtitle a="EVERY MAN" b="WAS GONE."/></AbsoluteFill>;
const SceneCar:React.FC=()=> <AbsoluteFill><CarInterior frame={useCurrentFrame()}/><Hud part="PART 02" route="ROUTE 09" time="00:31"/><div style={{position:"absolute",top:1080,left:80,right:80,textAlign:"center"}}><Txt size={27} color={colors.muted}>INSIDE THE CAR</Txt></div><Subtitle a="BUT YOU AND YOUR" b="BEST FRIEND REMAINED."/></AbsoluteFill>;
const SceneMap:React.FC=()=> <AbsoluteFill><MapScene/><Hud part="PART 03" route="UNKNOWN ROUTE" time="00:48"/><Subtitle a="WE FOUND A SIGNAL" b="60 KM AWAY."/></AbsoluteFill>;
const SceneWanted:React.FC=()=> <AbsoluteFill><WantedCard/><Hud part="PART 04" route="MISSING PERSON" time="01:02"/><Subtitle a="THEN WE SAW" b="OUR OWN FACES."/></AbsoluteFill>;
const SceneQuestion:React.FC=()=> <AbsoluteFill style={{background:"#070a16",justifyContent:"center",alignItems:"center"}}><Hud part="TO BE CONTINUED" route="?" time="01:07"/><Txt size={34} color={colors.yellow}>ONE QUESTION REMAINS</Txt><Txt size={100} style={{textAlign:"center",lineHeight:1.04,marginTop:55}}>WHY WERE</Txt><Txt size={100} color={colors.yellow} style={{textAlign:"center",lineHeight:1.04}}>WE STILL</Txt><Txt size={100} style={{textAlign:"center",lineHeight:1.04}}>HERE?</Txt><Subtitle a="EPISODE 01" b="CONTINUES..."/></AbsoluteFill>;

export const WhatIfStory:React.FC=()=> <AbsoluteFill style={{background:"#080b18"}}>
  <Sequence from={0} durationInFrames={240}><SceneIntro/></Sequence>
  <Sequence from={240} durationInFrames={300}><SceneEvent/></Sequence>
  <Sequence from={540} durationInFrames={480}><SceneCar/></Sequence>
  <Sequence from={1020} durationInFrames={300}><SceneMap/></Sequence>
  <Sequence from={1320} durationInFrames={240}><SceneWanted/></Sequence>
  <Sequence from={1560} durationInFrames={240}><SceneQuestion/></Sequence>
  <AbsoluteFill style={{pointerEvents:"none",background:"linear-gradient(90deg,rgba(0,0,0,.25),transparent 15%,transparent 85%,rgba(0,0,0,.25))"}}/>
</AbsoluteFill>;