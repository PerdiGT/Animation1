import React from 'react';
import {AbsoluteFill, useCurrentFrame, interpolate, spring, Easing} from 'remotion';

const W=1080,H=1920;
const clamp={extrapolateLeft:'clamp' as const,extrapolateRight:'clamp' as const};
const bg=(c:string)=>({background:c});
const txt=(size:number,color='white',weight=900):React.CSSProperties=>({fontFamily:'Arial, sans-serif',fontSize:size,color,fontWeight:weight,letterSpacing:-1,lineHeight:1.02,textShadow:'0 5px 18px rgba(0,0,0,.45)'});
const pop=(f:number,start:number,d=12)=>interpolate(f,[start,start+d],[0,1],clamp);
const caption=(f:number,lines:string[],start:number,color='white')=>{
 const idx=Math.min(lines.length-1,Math.max(0,Math.floor((f-start)/42)));
 const local=(f-start)%42;
 const y=interpolate(local,[0,8],[45,0],clamp);
 return <div style={{position:'absolute',left:65,right:65,bottom:205,transform:`translateY(${y}px)`,opacity:pop(f,start+idx*42,8),textAlign:'center',...txt(76,color),lineHeight:1.06}}>{lines[idx]}</div>;
};

const CrowdPerson:React.FC<{x:number;y:number;male:boolean;i:number;frame:number}> = ({x,y,male,i,frame})=>{
 const vanishStart=105+(i%7)*4;
 const vanish=male?interpolate(frame,[vanishStart,vanishStart+42],[1,0],clamp):1;
 const bob=Math.sin(frame*.09+i*1.7)*5;
 const colors=['#f6b73c','#e76f51','#4ea8de','#9b5de5','#43aa8b','#f28482'];
 const skin=['#b97852','#d99b72','#efbd91','#8e5b42'][i%4];
 return <g transform={`translate(${x} ${y+bob})`} opacity={vanish}>
   <ellipse cx="0" cy="148" rx="43" ry="12" fill="#101a28" opacity=".55"/>
   <circle cx="0" cy="0" r="35" fill={skin}/>
   {male?<path d="M-34 -8 Q-25 -48 8 -39 Q36 -32 34 -4 L24 -17 Q0 -31 -25 -9Z" fill="#252b36"/>:<path d="M-37 4 Q-48 -43 -5 -44 Q38 -45 39 5 L31 58 L-31 58Z" fill="#252b36"/>}
   <circle cx="-11" cy="3" r="3.5" fill="#20242b"/><circle cx="11" cy="3" r="3.5" fill="#20242b"/>
   <path d="M-8 17 Q0 23 9 16" fill="none" stroke="#6f382d" strokeWidth="3" strokeLinecap="round"/>
   <path d="M-48 52 Q0 35 48 52 L58 145 L-58 145Z" fill={male?'#3977a8':colors[i%colors.length]}/>
   <path d="M-35 140 L-40 205 L-9 205 L0 145Z" fill="#26384b"/>
   <path d="M10 145 L13 205 L43 205 L35 140Z" fill="#26384b"/>
   {male && <g opacity={interpolate(frame,[vanishStart,vanishStart+40],[0,1],clamp)}><path d="M-48 65 L-78 116" stroke="#e6c7a7" strokeWidth="18" strokeLinecap="round"/></g>}
 </g>;
};

const Dust:React.FC<{frame:number}> = ({frame})=>{
 const bits=Array.from({length:95},(_,i)=>{
  const start=104+(i%11)*3;
  const t=Math.max(0,frame-start);
  const x=150+(i*83)%780 + Math.sin(i*3)*15;
  const y=470+(i*47)%730;
  const dx=Math.sin(i*12.3)* (30+t*2.4);
  const dy=-t*(1.4+(i%5)*.45)+Math.cos(i*2)*12;
  const opacity=interpolate(frame,[start,start+12,start+58],[0,.95,0],clamp);
  const size=3+(i%5)*1.5;
  return <circle key={i} cx={x+dx} cy={y+dy} r={size} fill={i%3===0?'#ffd166':'#e9edf2'} opacity={opacity}/>;
 });
 return <g>{bits}</g>;
};

const CrowdScene:React.FC=()=>{
 const f=useCurrentFrame();
 const zoom=interpolate(f,[0,210],[1,1.13],clamp);
 const flash=interpolate(f,[100,110,120],[0,.55,0],clamp);
 const people=Array.from({length:17},(_,i)=>{
   const row=Math.floor(i/6),col=i%6;
   return {x:100+col*175+(row%2)*65,y:630+row*265,male:[0,2,3,5,6,8,9,11,12,14,15,16].includes(i),i};
 });
 return <AbsoluteFill style={{background:'linear-gradient(180deg,#1a2940 0%,#334d64 48%,#172535 100%)'}}>
   <div style={{position:'absolute',top:0,width:'100%',height:500,background:'linear-gradient(180deg,rgba(9,18,32,.8),transparent)'}}/>
   <div style={{position:'absolute',top:120,left:55,right:55,textAlign:'center',...txt(48,'#ffd166')}}>WHAT IF…</div>
   <div style={{position:'absolute',top:195,left:60,right:60,textAlign:'center',...txt(68)}}>SEMUA PRIA</div>
   <div style={{position:'absolute',top:275,left:60,right:60,textAlign:'center',...txt(68,'#ff6b6b')}}>TIBA-TIBA HILANG?</div>
   <div style={{position:'absolute',inset:0,transform:`scale(${zoom})`,transformOrigin:'50% 65%'}}>
    <div style={{position:'absolute',left:0,right:0,bottom:0,height:620,background:'linear-gradient(0deg,#111d2a,#23384a)'}}/>
    {people.map(p=><CrowdPerson key={p.i} {...p} frame={f}/>)}
    <Dust frame={f}/>
   </div>
   <AbsoluteFill style={{background:`rgba(255,255,255,${flash})`}}/>
   <div style={{position:'absolute',bottom:120,left:60,right:60,textAlign:'center',...txt(46,'#ffe08a'),opacity:interpolate(f,[125,145],[0,1],clamp)}}>DALAM HITUNGAN DETIK…</div>
 </AbsoluteFill>;
};

const NewsScene:React.FC=()=>{
 const f=useCurrentFrame(); const slide=interpolate(f,[0,18],[900,0],clamp);
 return <AbsoluteFill style={{background:'linear-gradient(145deg,#071526,#193b56)'}}>
  <div style={{position:'absolute',top:150,left:50,right:50,background:'#e63946',padding:24,transform:`translateX(${slide}px)`,...txt(58)}}>BREAKING NEWS</div>
  <div style={{position:'absolute',top:430,left:70,right:70,...txt(78),textAlign:'center'}}>SELURUH DUNIA</div>
  <div style={{position:'absolute',top:540,left:70,right:70,...txt(94,'#ffd166'),textAlign:'center'}}>KEHILANGAN</div>
  <div style={{position:'absolute',top:650,left:70,right:70,...txt(94,'#ff6b6b'),textAlign:'center'}}>PARA PRIA</div>
  <div style={{position:'absolute',top:950,left:110,right:110,height:400,border:'8px solid #dce8f2',borderRadius:25,background:'linear-gradient(135deg,#294b65,#0e2033)',display:'flex',alignItems:'center',justifyContent:'center',...txt(170,'#ffcf70')}}>0</div>
  <div style={{position:'absolute',top:1380,left:80,right:80,textAlign:'center',...txt(46,'#dce8f2')}}>JUMLAH PRIA YANG TERDETEKSI</div>
  {caption(f,['Tidak ada yang tahu','kenapa ini bisa terjadi.'],0)}
 </AbsoluteFill>;
};

const TwoSurvivors:React.FC=()=>{
 const f=useCurrentFrame();
 return <AbsoluteFill style={{background:'linear-gradient(180deg,#263b52,#101d2b)'}}>
  <div style={{position:'absolute',top:180,left:0,right:0,textAlign:'center',...txt(62)}}>TINGGAL KAMI?</div>
  <g/>
  <svg viewBox="0 0 1080 900" style={{position:'absolute',top:520,width:'100%'}}>
   {[330,740].map((x,i)=><g key={i} transform={`translate(${x} 120)`}>
    <circle cx="0" cy="0" r="75" fill={i?'#d69b72':'#b97852'}/><path d="M-70 -12 Q-50 -100 30 -72 Q75 -45 70 0 L45 -30 Q0 -60 -48 -15Z" fill="#242a35"/>
    <circle cx="-22" cy="3" r="7" fill="#1a1a1a"/><circle cx="22" cy="3" r="7" fill="#1a1a1a"/>
    <path d="M-20 35 Q0 20 20 35" stroke="#713e36" strokeWidth="6" fill="none"/>
    <path d="M-105 100 Q0 60 105 100 L130 520 L-130 520Z" fill={i?'#e76f51':'#3478a8'}/>
   </g>)}
  </svg>
  <div style={{position:'absolute',bottom:310,left:70,right:70,textAlign:'center',...txt(65,'#ffd166')}}>“SEMUA ORANG KE MANA?”</div>
  {caption(f,['Kami saling menatap.','Kota mendadak sunyi.'],0)}
 </AbsoluteFill>;
};

const MapScene:React.FC=()=>{
 const f=useCurrentFrame(); const draw=interpolate(f,[10,70],[0,1],clamp);
 return <AbsoluteFill style={{background:'#142b3d'}}>
  <div style={{position:'absolute',top:170,left:60,right:60,textAlign:'center',...txt(68)}}>TAPI ADA YANG ANEH…</div>
  <svg viewBox="0 0 900 1000" style={{position:'absolute',top:470,left:90,width:900}}>
   <rect x="0" y="0" width="900" height="850" rx="45" fill="#d8e4d4"/>
   {Array.from({length:8},(_,i)=><path key={i} d={`M${i*130-100} 0 L${i*130+180} 850`} stroke="#b2c7c2" strokeWidth="28" fill="none"/>)}
   {Array.from({length:7},(_,i)=><path key={i} d={`M0 ${i*130+40} L900 ${i*130-80}`} stroke="#b2c7c2" strokeWidth="24" fill="none"/>)}
   <path d="M130 650 Q320 520 430 420 T770 180" stroke="#ef476f" strokeWidth="16" strokeDasharray="22 18" fill="none" strokeDashoffset={900-draw*900}/>
   <circle cx="130" cy="650" r="30" fill="#277da1"/><circle cx="770" cy="180" r="34" fill="#ef476f"/>
  </svg>
  <div style={{position:'absolute',bottom:230,left:65,right:65,textAlign:'center',...txt(54,'#ffd166')}}>SEBUAH SINYAL MUNCUL DI PETA</div>
  {caption(f,['Lalu ponsel kami bergetar…','Ada satu pesan masuk.'],0)}
 </AbsoluteFill>;
};

const EndScene:React.FC=()=>{
 const f=useCurrentFrame(); const scale=spring({frame:f-12,fps:30,config:{damping:12}});
 return <AbsoluteFill style={{background:'radial-gradient(circle at 50% 40%,#3d254c,#0a1422 75%)'}}>
  <div style={{position:'absolute',top:300,left:60,right:60,textAlign:'center',...txt(65,'#ffd166')}}>PESAN MASUK</div>
  <div style={{position:'absolute',top:570,left:65,right:65,borderRadius:35,padding:45,background:'#edf2f4',color:'#17202a',transform:`scale(${Math.max(0,scale)})`,boxShadow:'0 20px 70px #0008'}}>
   <div style={{fontSize:34,fontWeight:800,color:'#6c757d'}}>UNKNOWN</div>
   <div style={{fontSize:64,fontWeight:900,lineHeight:1.1,marginTop:35}}>“KALIAN BUKAN SATU-SATUNYA YANG TERSISA.”</div>
  </div>
  <div style={{position:'absolute',bottom:260,left:65,right:65,textAlign:'center',...txt(72,'#ff6b6b')}}>BERSAMBUNG…</div>
 </AbsoluteFill>;
};

const Scene:React.FC<{start:number;duration:number;children:React.ReactNode}> = ({start,duration,children})=>{
 const f=useCurrentFrame(); const opacity=interpolate(f,[start,start+8,start+duration-8,start+duration],[0,1,1,0],clamp);
 return <AbsoluteFill style={{opacity}}>{children}</AbsoluteFill>;
};

export const WhatIfStory:React.FC=()=>{
 const f=useCurrentFrame();
 const cuts=[
  {s:0,d:240,c:<CrowdScene/>},
  {s:240,d:210,c:<NewsScene/>},
  {s:450,d:300,c:<TwoSurvivors/>},
  {s:750,d:330,c:<MapScene/>},
  {s:1080,d:300,c:<EndScene/>},
 ];
 return <AbsoluteFill style={{background:'#081321'}}>
  {cuts.map((x,i)=><Scene key={i} start={x.s} duration={x.d}>{x.c}</Scene>)}
  <div style={{position:'absolute',top:45,left:50,...txt(27,'#ffffff'),opacity:.65}}>WHAT IF?  •  EPISODE 01</div>
  <div style={{position:'absolute',bottom:45,left:0,right:0,textAlign:'center',...txt(24,'#ffffff'),opacity:.5}}>PERDI ORIGINAL STORY</div>
 </AbsoluteFill>;
};
