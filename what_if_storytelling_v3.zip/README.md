# What If Storytelling V3

Project Remotion vertikal 9:16 (1080x1920), 30 FPS, 60 detik.

## Jalankan di GitHub Codespaces
1. Upload dan extract ZIP ke repository.
2. Buka terminal di folder project.
3. Jalankan `npm install`
4. Jalankan `npm run start`
5. Di tab **Ports**, buka port 3000 (Remotion Studio).
6. Pilih komposisi `WhatIfStory`.

## Render video
Jalankan `npm run render`. Hasilnya ada di `out/video.mp4`.

V3 menambahkan adegan kerumunan, karakter pria/wanita, efek debu yang bergerak, berita, dua karakter yang tersisa, peta, dan cliffhanger. Semua elemen dibuat sebagai animasi vektor Remotion sehingga bisa diedit lewat kode.
