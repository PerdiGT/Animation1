import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {C, H, MONO, SANS, Stars, W, clamp, easeInOut, easeOut, rand, ramp} from '../components';

const CITIES: Array<[number, number]> = [
  [-74, 40], [-118, 34], [0, 51], [2, 48], [37, 55], [31, 30], [3, 6], [73, 19], [77, 28],
  [116, 40], [121, 31], [139, 35], [127, 37], [107, -6], [-47, -23], [-99, 19], [-58, -34],
  [28, -26], [151, -34], [29, 41], [55, 25], [100, 14], [-77, -12], [-79, 44], [13, 52],
  [37, -1], [121, 15], [-122, 47], [18, 59], [-43, -22],
];

const LIGHTS = CITIES.flatMap(([lon, lat], ci) =>
  Array.from({length: 16}).map((_, k) => ({
    lon: lon + (rand(ci * 50 + k) - 0.5) * 9,
    lat: lat + (rand(ci * 90 + k + 5) - 0.5) * 7,
    size: 1.6 + rand(ci + k * 3) * 2.6,
    key: ci * 100 + k,
  }))
);

export const Scene1Earth: React.FC = () => {
  const frame = useCurrentFrame();
  const cx = W / 2;
  const cy = H / 2 - 30;
  const R = 330 + frame * 0.4;
  const lon0 = 105 - frame * 0.38;
  const tilt = 0.35;

  const project = (lon: number, lat: number) => {
    const dl = ((lon - lon0) * Math.PI) / 180;
    const la = (lat * Math.PI) / 180;
    const x0 = Math.cos(la) * Math.sin(dl);
    const y0 = Math.sin(la);
    const z0 = Math.cos(la) * Math.cos(dl);
    const y1 = y0 * Math.cos(tilt) - z0 * Math.sin(tilt);
    const z1 = y0 * Math.sin(tilt) + z0 * Math.cos(tilt);
    return {x: cx + x0 * R, y: cy - y1 * R, z: z1};
  };

  const grid: string[] = [];
  for (const lat of [-60, -30, 0, 30, 60]) {
    let d = '';
    let pen = false;
    for (let lon = -180; lon <= 180; lon += 6) {
      const p = project(lon, lat);
      if (p.z > 0) {
        d += `${pen ? 'L' : 'M'}${p.x.toFixed(1)} ${p.y.toFixed(1)}`;
        pen = true;
      } else {
        pen = false;
      }
    }
    grid.push(d);
  }
  for (let lon = 0; lon < 360; lon += 30) {
    let d = '';
    let pen = false;
    for (let lat = -90; lat <= 90; lat += 6) {
      const p = project(lon, lat);
      if (p.z > 0) {
        d += `${pen ? 'L' : 'M'}${p.x.toFixed(1)} ${p.y.toFixed(1)}`;
        pen = true;
      } else {
        pen = false;
      }
    }
    grid.push(d);
  }

  const ring = (delay: number) => ramp(frame, 66 + delay, 110 + delay, easeOut);
  const r1 = ring(0);
  const r2 = ring(10);
  const flash = frame >= 66 ? Math.max(0, 1 - (frame - 66) / 10) * 0.35 : 0;
  const label =
    frame >= 66 ? '00:00:00' : frame >= 36 ? '23:59:59' : frame >= 6 ? '23:59:58' : '23:59:57';
  const c1 = ramp(frame, 82, 100);
  const c2 = ramp(frame, 92, 110);

  return (
    <AbsoluteFill
      style={{background: 'radial-gradient(ellipse at 50% 50%, #0a1a38 0%, #02050d 60%, #000 100%)'}}
    >
      <Stars count={220} seed={11} drift={0.08} />
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0}}>
        <defs>
          <radialGradient id="e-atmo" cx="50%" cy="50%" r="50%">
            <stop offset="84%" stopColor="#4d9bff" stopOpacity="0" />
            <stop offset="90%" stopColor="#5aa8ff" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#2a64d8" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="e-sphere" cx="32%" cy="30%" r="85%">
            <stop offset="0%" stopColor="#1a4a94" />
            <stop offset="45%" stopColor="#0a2150" />
            <stop offset="100%" stopColor="#01040c" />
          </radialGradient>
          <linearGradient id="e-shade" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#000" stopOpacity="0" />
            <stop offset="55%" stopColor="#000" stopOpacity="0.25" />
            <stop offset="100%" stopColor="#000" stopOpacity="0.8" />
          </linearGradient>
          <linearGradient id="e-rim" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#9fd0ff" stopOpacity="0.95" />
            <stop offset="60%" stopColor="#4a8cff" stopOpacity="0.2" />
            <stop offset="100%" stopColor="#4a8cff" stopOpacity="0" />
          </linearGradient>
        </defs>

        <circle cx={cx} cy={cy} r={R * 1.12} fill="url(#e-atmo)" />
        <circle cx={cx} cy={cy} r={R} fill="url(#e-sphere)" />
        {grid.map((d, i) => (
          <path key={i} d={d} fill="none" stroke="rgba(120,180,255,0.13)" strokeWidth={1} />
        ))}

        <g style={{filter: 'drop-shadow(0 0 3px #ff8a2a)'}}>
          {LIGHTS.map((l) => {
            const p = project(l.lon, l.lat);
            if (p.z <= 0.05) return null;
            const dist = Math.hypot(p.x - cx, p.y - cy) / R;
            const offAt = 66 + dist * 34 + rand(l.key) * 6;
            const keep = rand(l.key + 999) < 0.4;
            const k = ramp(frame, offAt, offAt + 7, easeInOut);
            const on = keep ? 1 - 0.65 * k : 1 - k;
            const flick = frame > offAt - 14 && frame < offAt ? (frame % 3 === 0 ? 0.25 : 1) : 1;
            const night = clamp(((p.x - cx) / R) * 0.7 + 0.65, 0.25, 1);
            const o = on * flick * night * Math.min(1, p.z * 3);
            if (o < 0.01) return null;
            return (
              <circle key={l.key} cx={p.x} cy={p.y} r={l.size * (0.6 + p.z * 0.6)} fill={C.amber} opacity={o} />
            );
          })}
        </g>

        <circle cx={cx} cy={cy} r={R} fill="url(#e-shade)" />
        <circle cx={cx} cy={cy} r={R} fill="none" stroke="url(#e-rim)" strokeWidth={2.5} />

        <circle
          cx={cx}
          cy={cy}
          r={R * 1.2}
          fill="none"
          stroke="rgba(120,180,255,0.35)"
          strokeWidth={2}
          strokeDasharray="2 14"
          transform={`rotate(${frame * 0.3} ${cx} ${cy})`}
        />
        <circle
          cx={cx}
          cy={cy}
          r={R * 1.28}
          fill="none"
          stroke="rgba(255,138,42,0.3)"
          strokeWidth={2}
          strokeDasharray="60 40 8 40"
          transform={`rotate(${-frame * 0.5} ${cx} ${cy})`}
        />

        {frame >= 66 && (
          <>
            <circle
              cx={cx}
              cy={cy}
              r={r1 * R * 1.35}
              fill="none"
              stroke={C.orange}
              strokeWidth={4 * (1 - r1) + 0.5}
              opacity={(1 - r1) * 0.9}
            />
            <circle
              cx={cx}
              cy={cy}
              r={r2 * R * 1.35}
              fill="none"
              stroke={C.amber}
              strokeWidth={3 * (1 - r2) + 0.5}
              opacity={(1 - r2) * 0.7}
            />
          </>
        )}
      </svg>

      {/* Jam tengah malam */}
      <div
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          top: 128,
          textAlign: 'center',
          fontFamily: MONO,
          fontSize: 58,
          letterSpacing: 10,
          color: frame >= 66 ? C.orange : C.white,
          textShadow: frame >= 66 ? '0 0 30px rgba(255,138,42,0.9)' : '0 0 18px rgba(140,190,255,0.6)',
        }}
      >
        {label}
      </div>
      <div
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          top: 200,
          textAlign: 'center',
          fontFamily: MONO,
          fontSize: 20,
          letterSpacing: 8,
          color: 'rgba(160,200,255,0.7)',
        }}
      >
        UTC · ORBITAL FEED 01
      </div>

      {frame >= 70 && (
        <div
          style={{
            position: 'absolute',
            left: 140,
            top: 128,
            fontFamily: MONO,
            fontSize: 24,
            letterSpacing: 4,
            color: C.orange,
            opacity: frame % 20 < 12 ? 1 : 0.25,
          }}
        >
          GLOBAL ANOMALY DETECTED
        </div>
      )}

      {/* Caption */}
      <div
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          top: 846,
          textAlign: 'center',
          fontFamily: SANS,
          fontWeight: 300,
          fontSize: 44,
          color: C.white,
          letterSpacing: 26 - c1 * 12,
          opacity: c1,
        }}
      >
        EVERY MAN ON EARTH
      </div>
      <div
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          top: 906,
          textAlign: 'center',
          fontFamily: SANS,
          fontWeight: 800,
          fontSize: 44,
          color: C.orange,
          letterSpacing: 22 - c2 * 10,
          opacity: c2,
          textShadow: '0 0 30px rgba(255,138,42,0.7)',
        }}
      >
        HAS VANISHED
      </div>

      {flash > 0 && (
        <AbsoluteFill style={{background: `rgba(255,170,90,${flash})`, mixBlendMode: 'screen'}} />
      )}
    </AbsoluteFill>
  );
};
