import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {C, Fog, GodRays, H, MONO, Particles, Person, SANS, Skyline, SplitText, Stars, W, easeInOut, lin, ramp} from '../components';

export const Scene3Reveal: React.FC = () => {
  const frame = useCurrentFrame();
  const push = 1 + ramp(frame, 0, 132, lin) * 0.08;
  const light = ramp(frame, 8, 52, easeInOut);
  const breathe = Math.sin(frame * 0.09) * 0.012;
  const tiltA = ramp(frame, 60, 92) * 6;
  const tiltB = -ramp(frame, 66, 98) * 6;
  const FEET = 845;

  const Label: React.FC<{x: number; top: number; from: number; text: string}> = ({x, top, from, text}) => {
    const p = ramp(frame, from, from + 14);
    return (
      <div
        style={{
          position: 'absolute',
          left: x,
          top,
          transform: 'translateX(-50%)',
          textAlign: 'center',
          opacity: p,
        }}
      >
        <div
          style={{
            fontFamily: MONO,
            fontSize: 26,
            letterSpacing: 6,
            color: C.amber,
            textShadow: '0 0 14px rgba(255,138,42,0.8)',
            whiteSpace: 'nowrap',
          }}
        >
          {text}
        </div>
        <div style={{width: 2, height: 46 * p, margin: '8px auto 0', background: C.orange, boxShadow: '0 0 8px #ff8a2a'}} />
      </div>
    );
  };

  return (
    <AbsoluteFill
      style={{
        background:
          'linear-gradient(to bottom, #01030a 0%, #07142c 45%, #1b2442 68%, #3a2a3c 78%, #0a1224 100%)',
      }}
    >
      <div
        style={{
          position: 'absolute',
          left: 0,
          top: 0,
          width: W,
          height: H,
          transform: `scale(${push})`,
          transformOrigin: '50% 72%',
        }}
      >
        <Stars count={130} seed={21} maxY={600} drift={0.04} />

        {/* bulan */}
        <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0}}>
          <defs>
            <radialGradient id="s3-moon" cx="50%" cy="50%" r="50%">
              <stop offset="20%" stopColor="#bcd6ff" stopOpacity="0.5" />
              <stop offset="100%" stopColor="#bcd6ff" stopOpacity="0" />
            </radialGradient>
          </defs>
          <circle cx={1420} cy={250} r={300} fill="url(#s3-moon)" />
          <circle cx={1420} cy={250} r={68} fill="#dfeaff" />
          <circle cx={1400} cy={235} r={14} fill="#b8c8e6" opacity={0.5} />
          <circle cx={1445} cy={270} r={10} fill="#b8c8e6" opacity={0.5} />
        </svg>

        <Skyline seed={21} baseY={790} minH={120} maxH={360} fill="#0a1630" lit={0.03} x={-100 - frame * 0.15} />
        <Skyline seed={33} baseY={830} minH={160} maxH={470} fill="#050b1a" lit={0.05} x={-100 - frame * 0.3} />

        {/* cahaya jingga di cakrawala */}
        <AbsoluteFill
          style={{
            background: 'radial-gradient(ellipse 900px 260px at 50% 74%, rgba(255,120,40,0.45), rgba(255,120,40,0) 70%)',
            opacity: light,
          }}
        />
        <GodRays x={W / 2} y={800} dir={180} spread={80} n={9} color="255,150,70" opacity={0.35 * light} length={1000} />
        {/* backlight di belakang karakter */}
        <AbsoluteFill
          style={{
            background: `radial-gradient(ellipse 520px 460px at 50% 66%, rgba(255,170,90,${0.55 * light}), rgba(255,100,30,0) 70%)`,
          }}
        />
        <Fog y={760} opacity={0.8} speed={0.4} color="120,150,220" />

        {/* rooftop + karakter */}
        <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0}}>
          <polygon points={`0,830 ${W},830 ${W},${H} 0,${H}`} fill="#02040a" />
          <rect x={0} y={826} width={W} height={6} fill={`rgba(255,150,70,${0.35 * light})`} />
          {Array.from({length: 17}).map((_, i) => (
            <rect key={i} x={i * 120 + 10} y={740} width={6} height={90} fill="#03060d" />
          ))}
          <rect x={0} y={745} width={W} height={5} fill="#03060d" />
          <rect x={0} y={790} width={W} height={5} fill="#03060d" />

          <Person x={860} y={FEET} scale={1.9} view="back" hood head={tiltA} breathe={breathe} glow={`rgba(255,160,80,${0.3 + 0.6 * light})`} />
          <Person x={1080} y={FEET} scale={2.0} view="back" pack head={tiltB} breathe={-breathe} glow={`rgba(255,160,80,${0.3 + 0.6 * light})`} />
        </svg>

        <Particles count={60} color={C.amber} seed={7} speed={0.5} size={3} />
      </div>

      {/* tipografi */}
      <div style={{position: 'absolute', left: 0, right: 0, top: 150, opacity: ramp(frame, 36, 44)}}>
        <SplitText text="BUT TWO REMAINED." start={38} size={92} spacing={0.16} stagger={2.5} />
      </div>
      <div
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          top: 272,
          textAlign: 'center',
          fontFamily: MONO,
          fontSize: 22,
          letterSpacing: 8,
          color: 'rgba(160,200,255,0.8)',
          opacity: ramp(frame, 96, 112),
        }}
      >
        SUBJECT 01 · SUBJECT 02 — STATUS: ALIVE
      </div>

      <Label x={860} top={395} from={74} text="YOU" />
      <Label x={1080} top={372} from={84} text="YOUR BEST FRIEND" />

      <div style={{position: 'absolute', left: 0, right: 0, bottom: 130, textAlign: 'center', fontFamily: SANS, fontStyle: 'italic', fontSize: 30, color: 'rgba(238,244,255,0.85)', opacity: ramp(frame, 100, 114)}}>
        Four billion people gone. Two left standing.
      </div>
    </AbsoluteFill>
  );
};
