import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {C, GodRays, H, MONO, Particles, Person, SANS, Skyline, Stars, W, easeOut, rand, ramp} from '../components';

const CRACKS = Array.from({length: 7}).map((_, k) => {
  const ang = (k / 7) * Math.PI * 2 + 0.3;
  return Array.from({length: 7})
    .map((__, s) => {
      const rr = s * 62 + 10;
      const jitter = (rand(k * 10 + s) - 0.5) * 40;
      const x = Math.cos(ang) * rr + Math.cos(ang + Math.PI / 2) * jitter;
      const y = Math.sin(ang) * rr * 1.3 + Math.sin(ang + Math.PI / 2) * jitter;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(' ');
});

const TEXT: React.CSSProperties = {
  textAlign: 'center',
  fontFamily: SANS,
  fontWeight: 800,
  fontSize: 118,
  letterSpacing: 10,
  lineHeight: 1.12,
};

const Word: React.FC<{t: string; from: number; color?: string}> = ({t, from, color = C.white}) => {
  const frame = useCurrentFrame();
  const p = ramp(frame, from, from + 14);
  return (
    <span
      style={{
        display: 'inline-block',
        margin: '0 18px',
        opacity: p,
        transform: `translateY(${(1 - p) * 30}px) scale(${1.4 - 0.4 * p})`,
        filter: `blur(${(1 - p) * 14}px)`,
        color,
        textShadow: `0 0 30px rgba(255,138,42,${0.6 * p}), 0 0 80px rgba(255,138,42,${0.35 * p})`,
      }}
    >
      {t}
    </span>
  );
};

export const Scene5Cliffhanger: React.FC = () => {
  const frame = useCurrentFrame();
  const open = ramp(frame, 0, 34, easeOut);
  const pulse = 0.85 + 0.15 * Math.sin(frame * 0.35);
  const push = 1 + frame * 0.0007;
  const punch = frame >= 70 ? 1 + Math.max(0, 1 - (frame - 70) / 10) * 0.05 : 1;
  const flash = frame >= 70 ? Math.max(0, 1 - (frame - 70) / 8) * 0.55 : 0;
  const glitching = (frame >= 76 && frame <= 80) || (frame >= 84 && frame <= 86);
  const pointAmt = ramp(frame, 6, 26);
  const breathe = Math.sin(frame * 0.09) * 0.01;

  const ghosts = [
    {col: 'rgba(255,50,50,0.7)', dx: -9, k: 1},
    {col: 'rgba(40,220,255,0.7)', dx: 9, k: 2},
  ];

  return (
    <AbsoluteFill
      style={{
        background: `radial-gradient(ellipse at 50% 28%, rgba(255,120,40,${0.45 * open}) 0%, rgba(40,60,120,${0.35 * open}) 35%, #010208 75%)`,
      }}
    >
      <div
        style={{
          position: 'absolute',
          left: 0,
          top: 0,
          width: W,
          height: H,
          transform: `scale(${push * punch})`,
          transformOrigin: '50% 60%',
        }}
      >
        <Stars count={150} seed={51} maxY={700} drift={0.03} />

        {/* retakan langit / portal */}
        <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0}}>
          <defs>
            <radialGradient id="s5-core" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#ffffff" stopOpacity="1" />
              <stop offset="30%" stopColor="#ffd9a8" stopOpacity="0.9" />
              <stop offset="65%" stopColor="#ff8a2a" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#ff5a10" stopOpacity="0" />
            </radialGradient>
            <linearGradient id="s5-streak" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#ffb25e" stopOpacity="0" />
              <stop offset="50%" stopColor="#fff1d6" stopOpacity="1" />
              <stop offset="100%" stopColor="#ffb25e" stopOpacity="0" />
            </linearGradient>
            <radialGradient id="s5-floor" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#ff8a2a" stopOpacity="0.5" />
              <stop offset="100%" stopColor="#ff8a2a" stopOpacity="0" />
            </radialGradient>
          </defs>

          {[0, 1, 2].map((k) => {
            const tt = ((frame + k * 20) % 60) / 60;
            return (
              <ellipse
                key={k}
                cx={960}
                cy={300}
                rx={80 + tt * 700}
                ry={(80 + tt * 700) * 0.55}
                fill="none"
                stroke={C.orange}
                strokeWidth={3}
                opacity={(1 - tt) * 0.5 * open}
              />
            );
          })}
          <ellipse cx={960} cy={300} rx={260 * open * pulse} ry={330 * open * pulse} fill="url(#s5-core)" opacity={0.6} />
          <ellipse cx={960} cy={300} rx={70 * open * pulse} ry={210 * open * pulse} fill="url(#s5-core)" />
          <rect x={960 - 760 * open} y={297} width={1520 * open} height={6} fill="url(#s5-streak)" opacity={0.9 * pulse} />
          <g transform="translate(960 300)" opacity={open}>
            {CRACKS.map((p, k) => (
              <polyline
                key={k}
                points={p}
                fill="none"
                stroke="#ffe2bd"
                strokeWidth={2}
                opacity={0.6 + 0.4 * Math.sin(frame * 0.5 + k)}
              />
            ))}
          </g>
        </svg>

        <GodRays x={960} y={300} dir={0} spread={70} n={9} color="255,150,70" opacity={0.4 * open} length={1100} />
        <Skyline seed={77} baseY={960} minH={200} maxH={520} fill="#02050c" lit={0.01} x={-200} />

        {/* tanah + karakter */}
        <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0}}>
          <rect x={0} y={950} width={W} height={H - 950} fill="#010308" />
          <ellipse cx={960} cy={952} rx={700} ry={30} fill="url(#s5-floor)" opacity={open} />
          <Person x={880} y={965} scale={1.25} view="back" hood head={-4} breathe={breathe} glow="rgba(255,170,90,0.95)" />
          <Person x={1040} y={965} scale={1.3} view="back" pack point={pointAmt} breathe={-breathe} glow="rgba(255,170,90,0.95)" />
        </svg>

        <Particles count={70} color={C.orange} seed={13} speed={0.8} size={3} />
      </div>

      {/* teks cliffhanger */}
      <div style={{position: 'absolute', left: 0, right: 0, top: 395, ...TEXT}}>
        <div>
          {['WHY', 'WERE', 'WE'].map((t, i) => (
            <Word key={t} t={t} from={26 + i * 8} />
          ))}
        </div>
        <div>
          {['STILL', 'HERE?'].map((t, i) => (
            <Word key={t} t={t} from={54 + i * 14} color={i === 1 ? C.orange : C.white} />
          ))}
        </div>
      </div>

      {glitching &&
        ghosts.map((g) => (
          <div
            key={g.k}
            style={{
              position: 'absolute',
              left: 0,
              right: 0,
              top: 395,
              ...TEXT,
              color: g.col,
              transform: `translateX(${g.dx}px)`,
              mixBlendMode: 'screen',
              clipPath: `inset(${rand(frame + g.k) * 60}% 0 ${rand(frame + g.k + 9) * 30}% 0)`,
            }}
          >
            <div>WHY WERE WE</div>
            <div>STILL HERE?</div>
          </div>
        ))}

      <div
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          top: 672,
          textAlign: 'center',
          fontFamily: MONO,
          fontSize: 24,
          letterSpacing: 12,
          color: 'rgba(255,200,150,0.8)',
          opacity: ramp(frame, 72, 84),
        }}
      >
        TO BE CONTINUED...
      </div>

      {flash > 0 && <AbsoluteFill style={{background: `rgba(255,235,210,${flash})`, mixBlendMode: 'screen'}} />}
    </AbsoluteFill>
  );
};
