import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {
  C,
  Fog,
  GodRays,
  H,
  MONO,
  Particles,
  SANS,
  Skyline,
  Stars,
  W,
  clamp,
  easeInOut,
  fmt,
  lin,
  rand,
  ramp,
} from '../components';

const F = 900; // focal length
const HZ = 520; // horizon (y layar)
const CAM = 2.6; // tinggi kamera
const ROAD = 7;
const WALL = 10.5;
const BLEN = 12;
const NEAR = 1.4;
const FAR = 160;

type V3 = [number, number, number];
const px = (X: number, Z: number) => W / 2 + (X * F) / Z;
const py = (Y: number, Z: number) => HZ + (Y * F) / Z;
const quad = (...pts: V3[]): string =>
  pts.map(([X, Y, Z]) => `${px(X, Z).toFixed(1)},${py(Y, Z).toFixed(1)}`).join(' ');

const Building: React.FC<{i: number; side: number; camZ: number; frame: number}> = ({
  i,
  side,
  camZ,
  frame,
}) => {
  const seed = i * 2 + (side === 1 ? 1 : 0);
  const bh = 14 + rand(seed + 3.3) * 34;
  const zStart = i * BLEN - camZ;
  const zEnd = i * BLEN + BLEN - 0.4 - camZ;
  if (zEnd <= NEAR || zStart > FAR) return null;
  const z1 = Math.max(NEAR, zStart);
  const X = side * WALL;
  const fogMix = clamp((z1 - 20) / 120);
  const L = 7 + rand(seed + 1.1) * 7;
  const els: React.ReactNode[] = [];
  els.push(
    <polygon
      key="wall"
      points={quad([X, CAM, z1], [X, CAM - bh, z1], [X, CAM - bh, zEnd], [X, CAM, zEnd])}
      fill={`hsl(218, 48%, ${L}%)`}
    />
  );
  const cols = 4;
  const rowH = 3.4;
  const rows = Math.floor(bh / rowH);
  for (let r = 1; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const k = seed * 1000 + r * 10 + c;
      const Za = zStart + (zEnd - zStart) * ((c + 0.2) / cols);
      const Zb = zStart + (zEnd - zStart) * ((c + 0.8) / cols);
      if (Za < NEAR) continue;
      let fill = 'rgba(14,30,62,0.85)';
      let op = 1;
      if (rand(k + 0.5) < 0.07) {
        fill = C.amber;
        op = rand(k + 2) < 0.2 ? (Math.sin(frame * 0.7 + k) > 0.1 ? 1 : 0.15) : 0.9;
      }
      const yb = CAM - (r + 0.25) * rowH;
      const yt = CAM - (r + 0.75) * rowH;
      els.push(
        <polygon
          key={`${r}-${c}`}
          points={quad([X, yb, Za], [X, yt, Za], [X, yt, Zb], [X, yb, Zb])}
          fill={fill}
          opacity={op}
        />
      );
    }
  }
  return <g opacity={1 - fogMix * 0.8}>{els}</g>;
};

const CARS = [
  {z: 16, x: -3.4, hz: 0},
  {z: 31, x: 3.1, hz: 1},
  {z: 47, x: -2.6, hz: 0},
  {z: 66, x: 2.4, hz: 1},
  {z: 88, x: -3.5, hz: 0},
  {z: 118, x: 3, hz: 1},
];

export const Scene2Street: React.FC = () => {
  const frame = useCurrentFrame();
  const camZ = frame * 0.16;
  const shakeX = Math.sin(frame * 0.09) * 2.2;
  const shakeY = Math.cos(frame * 0.13) * 1.6;
  const glitch = (frame >= 34 && frame <= 38) || (frame >= 88 && frame <= 90);
  const gx = glitch ? (rand(frame) - 0.5) * 24 : 0;

  /* bangunan (jauh -> dekat) */
  const first = Math.floor(camZ / BLEN) - 1;
  const count = Math.ceil(FAR / BLEN) + 3;
  const buildings: React.ReactNode[] = [];
  for (let n = count - 1; n >= 0; n--) {
    const i = first + n;
    buildings.push(<Building key={`l${i}`} i={i} side={-1} camZ={camZ} frame={frame} />);
    buildings.push(<Building key={`r${i}`} i={i} side={1} camZ={camZ} frame={frame} />);
  }

  /* marka jalan */
  const dashes: React.ReactNode[] = [];
  const d0 = Math.floor(camZ / 6);
  for (let k = d0; k < d0 + 28; k++) {
    const za = k * 6 - camZ;
    const zb = za + 2.6;
    if (zb < NEAR) continue;
    const z0 = Math.max(za, NEAR);
    dashes.push(
      <polygon
        key={`d${k}`}
        points={quad([-0.12, CAM, z0], [0.12, CAM, z0], [0.12, CAM, zb], [-0.12, CAM, zb])}
        fill="rgba(255,200,140,0.6)"
      />
    );
  }

  /* lampu jalan */
  const lamps: React.ReactNode[] = [];
  for (const side of [-1, 1]) {
    const k0 = Math.floor(camZ / 18) - 1;
    for (let k = k0; k < k0 + 11; k++) {
      const z = k * 18 + (side === 1 ? 13 : 4) - camZ;
      if (z < NEAR + 0.6 || z > FAR) continue;
      const X = side * (ROAD + 0.6);
      const topY = CAM - 7.5;
      const hx = X - side * 1.9;
      const flick = rand(k * 3 + side) < 0.3 ? (Math.sin(frame * 1.3 + k * 3) > -0.2 ? 1 : 0.15) : 1;
      const sw = Math.max(1.5, (0.2 * F) / z);
      const fogO = 1 - clamp((z - 30) / 130) * 0.7;
      lamps.push(
        <g key={`lamp${side}-${k}`} opacity={fogO}>
          <ellipse
            cx={px(X - side * 2.4, z)}
            cy={py(CAM, z)}
            rx={(5.5 * F) / z}
            ry={Math.max(2, (F * CAM * 5) / (z * z) / 2)}
            fill="url(#s2-pool)"
            opacity={0.55 * flick}
          />
          <line x1={px(X, z)} y1={py(CAM, z)} x2={px(X, z)} y2={py(topY, z)} stroke="#050b17" strokeWidth={sw} />
          <line x1={px(X, z)} y1={py(topY, z)} x2={px(hx, z)} y2={py(topY, z)} stroke="#050b17" strokeWidth={sw * 0.7} />
          <circle
            cx={px(hx, z)}
            cy={py(topY, z)}
            r={Math.max(4, (3.2 * F) / z)}
            fill="url(#s2-lamp)"
            opacity={flick}
          />
        </g>
      );
    }
  }

  /* mobil terbengkalai */
  const cars = CARS.map((c, n) => {
    const Z = c.z - camZ;
    if (Z < 3.4 || Z > FAR) return null;
    const rr = (x1: number, x2: number, top: number, bot: number) => ({
      x: px(c.x + x1, Z),
      y: py(CAM - top, Z),
      width: ((x2 - x1) * F) / Z,
      height: ((top - bot) * F) / Z,
    });
    const blink = c.hz === 1 && Math.floor(frame / 14) % 2 === 0;
    const o = 1 - clamp((Z - 30) / 120) * 0.8;
    const tail = blink ? C.orange : '#4a1308';
    return (
      <g key={`car${n}`} opacity={o}>
        <rect {...rr(-0.95, 0.95, 1.15, 0.3)} fill="#07101f" />
        <polygon
          points={quad(
            [c.x - 0.85, CAM - 1.15, Z],
            [c.x - 0.65, CAM - 1.7, Z],
            [c.x + 0.65, CAM - 1.7, Z],
            [c.x + 0.85, CAM - 1.15, Z]
          )}
          fill="#060d1b"
        />
        <rect {...rr(-0.6, 0.6, 1.62, 1.2)} fill="rgba(60,100,170,0.35)" />
        <rect {...rr(-0.85, -0.5, 0.45, 0)} fill="#010307" />
        <rect {...rr(0.5, 0.85, 0.45, 0)} fill="#010307" />
        <rect {...rr(-0.92, -0.55, 1.0, 0.8)} fill={tail} />
        <rect {...rr(0.55, 0.92, 1.0, 0.8)} fill={tail} />
        {blink && <circle cx={px(c.x, Z)} cy={py(CAM - 0.9, Z)} r={(1.6 * F) / Z} fill="url(#s2-lamp)" />}
      </g>
    );
  });

  /* HUD berita */
  const slide = ramp(frame, 30, 54);
  const tickerX = 1500 - Math.max(0, frame - 40) * 7;
  const tag = '5TH AVENUE · NEW YORK'.slice(0, Math.floor(ramp(frame, 4, 36, lin) * 21));
  const counter = ramp(frame, 14, 110, easeInOut) * 4048000000;

  return (
    <AbsoluteFill
      style={{
        background:
          'linear-gradient(to bottom, #01030a 0%, #07142c 35%, #14284a 48%, #2c2f4a 52%, #01030a 100%)',
      }}
    >
      <div
        style={{
          position: 'absolute',
          left: 0,
          top: 0,
          width: W,
          height: H,
          transform: `translate(${shakeX + gx}px, ${shakeY}px) scale(1.04)`,
        }}
      >
        <Stars count={90} seed={5} maxY={HZ} drift={0.03} />
        <AbsoluteFill
          style={{
            background: `radial-gradient(ellipse 700px 200px at 50% ${HZ}px, rgba(255,130,50,0.55), rgba(255,130,50,0) 70%)`,
          }}
        />
        <Skyline seed={9} baseY={HZ + 6} minH={50} maxH={190} fill="#0a1830" lit={0.05} x={-340} />

        <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0}}>
          <defs>
            <linearGradient id="s2-ground" gradientUnits="userSpaceOnUse" x1="0" y1={HZ} x2="0" y2={H}>
              <stop offset="0%" stopColor="#1b3358" />
              <stop offset="25%" stopColor="#0b1a30" />
              <stop offset="100%" stopColor="#02050b" />
            </linearGradient>
            <radialGradient id="s2-lamp" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#fff1d6" stopOpacity="1" />
              <stop offset="25%" stopColor="#ffb25e" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#ff8a2a" stopOpacity="0" />
            </radialGradient>
            <radialGradient id="s2-pool" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#ffb25e" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#ff8a2a" stopOpacity="0" />
            </radialGradient>
          </defs>

          <polygon
            points={quad([-WALL, CAM, NEAR], [WALL, CAM, NEAR], [WALL, CAM, FAR], [-WALL, CAM, FAR])}
            fill="url(#s2-ground)"
          />
          <polygon
            points={quad([-WALL, CAM, NEAR], [-ROAD, CAM, NEAR], [-ROAD, CAM, FAR], [-WALL, CAM, FAR])}
            fill="rgba(40,64,100,0.35)"
          />
          <polygon
            points={quad([ROAD, CAM, NEAR], [WALL, CAM, NEAR], [WALL, CAM, FAR], [ROAD, CAM, FAR])}
            fill="rgba(40,64,100,0.35)"
          />
          <polygon
            points={quad([-ROAD, CAM, NEAR], [-ROAD + 0.12, CAM, NEAR], [-ROAD + 0.12, CAM, FAR], [-ROAD, CAM, FAR])}
            fill="rgba(255,255,255,0.18)"
          />
          <polygon
            points={quad([ROAD - 0.12, CAM, NEAR], [ROAD, CAM, NEAR], [ROAD, CAM, FAR], [ROAD - 0.12, CAM, FAR])}
            fill="rgba(255,255,255,0.18)"
          />
          {dashes}
          {buildings}
          {lamps}
          {cars}
        </svg>

        <GodRays x={W / 2} y={HZ} dir={180} spread={60} n={7} color="255,150,70" opacity={0.25} length={900} />
        <Fog y={HZ - 40} opacity={0.7} speed={0.5} />
        <Particles count={50} color="#a9c7ff" seed={4} speed={0.3} size={2} />
      </div>

      {/* scanline gaya siaran TV */}
      <AbsoluteFill
        style={{
          background:
            'repeating-linear-gradient(to bottom, rgba(0,0,0,0.18) 0px, rgba(0,0,0,0.18) 1px, transparent 1px, transparent 4px)',
          opacity: 0.5,
          pointerEvents: 'none',
        }}
      />

      {/* tag lokasi */}
      <div
        style={{
          position: 'absolute',
          left: 140,
          top: 128,
          fontFamily: MONO,
          fontSize: 26,
          letterSpacing: 5,
          color: C.amber,
          textShadow: '0 0 12px rgba(255,138,42,0.6)',
        }}
      >
        {tag}
        {frame % 20 < 12 ? '_' : ''}
      </div>
      <div style={{position: 'absolute', left: 140, top: 166, fontFamily: MONO, fontSize: 20, letterSpacing: 4, color: 'rgba(160,200,255,0.7)'}}>
        LOCAL TIME 00:14
      </div>

      {/* LIVE + counter */}
      <div
        style={{
          position: 'absolute',
          right: 140,
          top: 126,
          display: 'flex',
          alignItems: 'center',
          gap: 12,
          fontFamily: SANS,
          fontWeight: 800,
          fontSize: 28,
          letterSpacing: 6,
          color: C.white,
        }}
      >
        <div
          style={{
            width: 16,
            height: 16,
            borderRadius: '50%',
            background: '#ff2d2d',
            boxShadow: '0 0 14px #ff2d2d',
            opacity: frame % 30 < 20 ? 1 : 0.2,
          }}
        />
        LIVE
      </div>
      <div style={{position: 'absolute', right: 140, top: 176, textAlign: 'right', opacity: ramp(frame, 14, 30)}}>
        <div style={{fontFamily: MONO, fontSize: 18, letterSpacing: 5, color: 'rgba(160,200,255,0.8)'}}>
          CONFIRMED MISSING
        </div>
        <div style={{fontFamily: MONO, fontSize: 40, letterSpacing: 3, color: C.orange, textShadow: '0 0 16px rgba(255,138,42,0.7)'}}>
          {fmt(counter)}
        </div>
      </div>

      {/* lower third berita darurat */}
      <div
        style={{
          position: 'absolute',
          left: 120,
          bottom: 130,
          width: 1500,
          transform: `translateX(${(1 - slide) * -1700}px)`,
        }}
      >
        <div style={{display: 'flex', alignItems: 'stretch'}}>
          <div
            style={{
              background: C.orange,
              color: '#1a0a00',
              fontFamily: SANS,
              fontWeight: 900,
              fontSize: 32,
              letterSpacing: 4,
              padding: '14px 26px',
            }}
          >
            BREAKING
          </div>
          <div
            style={{
              flex: 1,
              background: 'rgba(6,14,30,0.9)',
              color: C.white,
              fontFamily: SANS,
              fontWeight: 600,
              fontSize: 32,
              padding: '14px 30px',
              borderBottom: `3px solid ${C.orange}`,
            }}
          >
            GLOBAL EMERGENCY: ALL MEN UNACCOUNTED FOR
          </div>
        </div>
        <div style={{overflow: 'hidden', background: 'rgba(0,0,0,0.7)', padding: '8px 0'}}>
          <div
            style={{
              whiteSpace: 'nowrap',
              fontFamily: MONO,
              fontSize: 22,
              color: C.amber,
              transform: `translateX(${tickerX}px)`,
              letterSpacing: 2,
            }}
          >
            GOVERNMENTS DECLARE STATE OF EMERGENCY • UN SECURITY COUNCIL CONVENES • NO MALE SURVIVORS CONFIRMED • BORDERS CLOSED • SATELLITE FEEDS SHOW EMPTY CITIES •
          </div>
        </div>
      </div>
    </AbsoluteFill>
  );
};
