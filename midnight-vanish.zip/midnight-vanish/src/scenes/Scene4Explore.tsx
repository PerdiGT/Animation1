import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {C, Fog, H, MONO, Particles, Person, SANS, Skyline, Stars, W, clamp, easeInOut, lin, rand, ramp} from '../components';

const GROUND = 880;

const CARDS = [
  {from: 6, title: 'DOWNTOWN DISTRICT', sub: 'LIFE SIGNS: 0  •  POWER: ON'},
  {from: 52, title: 'HIGHWAY 9', sub: 'TRAFFIC: NONE  •  VEHICLES: ABANDONED'},
  {from: 98, title: 'NORTHERN SKY', sub: 'SATELLITE LINK: LOST  •  SOURCE: UNKNOWN'},
];

const SUBS = [
  {from: 14, to: 52, t: '"Hello...? Is anyone out there?"'},
  {from: 62, to: 102, t: '"They\'re all gone. Every single one."'},
  {from: 110, to: 150, t: '"...Do you see that light?"'},
];

const Bus: React.FC<{x: number; y: number; frame: number}> = ({x, y, frame}) => (
  <g transform={`translate(${x} ${y})`}>
    <rect x={0} y={-150} width={430} height={150} rx={16} fill="#050a16" />
    <rect x={0} y={-60} width={430} height={5} fill="rgba(255,138,42,0.35)" />
    {Array.from({length: 7}).map((_, i) => (
      <rect
        key={i}
        x={20 + i * 57}
        y={-128}
        width={44}
        height={44}
        rx={4}
        fill={i === 3 && frame % 40 < 30 ? 'rgba(255,178,94,0.8)' : 'rgba(40,70,120,0.45)'}
      />
    ))}
    <circle cx={85} cy={0} r={28} fill="#010307" />
    <circle cx={340} cy={0} r={28} fill="#010307" />
  </g>
);

const Car: React.FC<{x: number; y: number; frame: number; hazard?: boolean}> = ({x, y, frame, hazard}) => (
  <g transform={`translate(${x} ${y})`}>
    <path
      d="M0 -10 L0 -55 Q0 -68 18 -70 L60 -74 L90 -108 Q96 -116 112 -116 L170 -116 Q186 -116 194 -106 L214 -76 L252 -70 Q262 -66 262 -54 L262 -10 Z"
      fill="#060c1a"
    />
    <circle cx={62} cy={-6} r={24} fill="#010307" />
    <circle cx={202} cy={-6} r={24} fill="#010307" />
    {hazard && frame % 30 < 15 && <circle cx={6} cy={-52} r={30} fill="url(#s4-glow)" />}
  </g>
);

export const Scene4Explore: React.FC = () => {
  const frame = useCurrentFrame();

  /* jarak tempuh: konstan 10px/frame lalu melambat halus */
  const t = Math.min(frame, 140) - 120;
  const dist = frame < 120 ? frame * 10 : 1200 + 10 * t - 0.25 * t * t;
  const phase = dist * 0.022;
  const walk = 1 - ramp(frame, 118, 142, easeInOut);
  const look = ramp(frame, 126, 148);
  const point = ramp(frame, 130, 150);
  const breathe = Math.sin(frame * 0.09) * 0.01;

  const lampXs = [0, 1, 2, 3].map((i) => ((((i * 880 - dist) % 3520) + 3520) % 3520) - 300);
  const boost = clamp(lampXs.reduce((s, x) => s + Math.exp(-Math.pow((x + 95 - 900) / 260, 2)), 0));
  const glow = `rgba(255,150,60,${0.3 + 0.7 * boost})`;

  const sunrise = 0.15 + 0.55 * ramp(frame, 90, 150);
  const camScale = 1 + frame * 0.0004;
  const wobble = Math.sin(frame * 0.2) * 1.5;

  return (
    <AbsoluteFill
      style={{background: 'linear-gradient(to bottom, #01030a 0%, #06122a 40%, #12264a 70%, #1b2442 100%)'}}
    >
      <div
        style={{
          position: 'absolute',
          left: 0,
          top: 0,
          width: W,
          height: H,
          transform: `translateY(${wobble}px) scale(${camScale})`,
          transformOrigin: '50% 70%',
        }}
      >
        <Stars count={130} seed={31} maxY={620} drift={0.04} />
        <AbsoluteFill
          style={{
            background: `radial-gradient(ellipse 800px 500px at 82% 62%, rgba(255,120,40,${sunrise}), rgba(255,120,40,0) 70%)`,
          }}
        />

        <Skyline seed={41} baseY={700} minH={150} maxH={380} fill="#0b1a38" lit={0.02} x={-dist * 0.05} />
        <Skyline seed={57} baseY={800} minH={200} maxH={520} fill="#06101f" lit={0.05} x={-dist * 0.16} />
        <Skyline seed={63} baseY={GROUND} minH={380} maxH={760} fill="#030710" lit={0.04} x={-dist * 0.3} />

        {/* papan neon */}
        <div
          style={{
            position: 'absolute',
            left: 1500 - dist * 0.3,
            top: 560,
            padding: '6px 22px',
            border: '3px solid #ff5a3a',
            borderRadius: 8,
            fontFamily: MONO,
            fontSize: 40,
            letterSpacing: 8,
            color: '#ff6a3a',
            textShadow: '0 0 14px #ff4a2a, 0 0 40px #ff4a2a',
            boxShadow: '0 0 18px rgba(255,74,42,0.6)',
            opacity: frame % 23 < 3 ? 0.2 : 1,
          }}
        >
          OPEN
        </div>
        <div
          style={{
            position: 'absolute',
            left: 2300 - dist * 0.3,
            top: 520,
            fontFamily: MONO,
            fontSize: 44,
            letterSpacing: 8,
            color: '#7fd6ff',
            textShadow: '0 0 14px #3ab0ff, 0 0 40px #3ab0ff',
            opacity: frame % 31 < 4 ? 0.3 : 1,
          }}
        >
          24H
        </div>

        <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0}}>
          <defs>
            <linearGradient id="s4-ground" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#15294a" />
              <stop offset="100%" stopColor="#02050b" />
            </linearGradient>
            <linearGradient id="s4-cone" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#ffb25e" stopOpacity="0.3" />
              <stop offset="100%" stopColor="#ff8a2a" stopOpacity="0" />
            </linearGradient>
            <radialGradient id="s4-glow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#fff1d6" stopOpacity="1" />
              <stop offset="30%" stopColor="#ffb25e" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#ff8a2a" stopOpacity="0" />
            </radialGradient>
          </defs>

          {/* kendaraan terbengkalai */}
          <Bus x={1700 - dist * 0.55} y={GROUND + 12} frame={frame} />
          <Car x={2400 - dist * 0.55} y={GROUND + 12} frame={frame} hazard />
          <Car x={900 - dist * 0.55} y={GROUND + 12} frame={frame} />

          {/* tanah */}
          <rect x={0} y={GROUND} width={W} height={H - GROUND} fill="url(#s4-ground)" />
          <rect x={0} y={GROUND - 2} width={W} height={4} fill="rgba(255,150,70,0.25)" />
          {Array.from({length: 7}).map((_, i) => {
            const x = ((((i * 420 - dist) % 2940) + 2940) % 2940) - 300;
            return <rect key={i} x={x} y={958} width={220} height={8} fill="rgba(255,200,140,0.35)" />;
          })}

          {/* lampu jalan */}
          {lampXs.map((x, i) => (
            <g key={i}>
              <ellipse cx={x + 95} cy={GROUND + 28} rx={230} ry={22} fill="url(#s4-glow)" opacity={0.3} />
              <polygon
                points={`${x + 60},${GROUND - 444} ${x + 130},${GROUND - 444} ${x + 260},${GROUND + 16} ${x - 70},${GROUND + 16}`}
                fill="url(#s4-cone)"
              />
              <rect x={x - 6} y={GROUND - 470} width={12} height={490} fill="#040810" />
              <rect x={x - 6} y={GROUND - 470} width={100} height={8} fill="#040810" />
              <rect x={x + 60} y={GROUND - 466} width={70} height={14} rx={6} fill="#0a1224" />
              <circle cx={x + 95} cy={GROUND - 452} r={90} fill="url(#s4-glow)" opacity={0.85} />
            </g>
          ))}

          {/* karakter berjalan */}
          <Person x={770} y={925} scale={1.75} view="side" walk={walk} phase={phase} head={-look * 16} hood glow={glow} breathe={breathe} />
          <Person x={1000} y={925} scale={1.8} view="side" walk={walk} phase={phase + 0.5} head={-look * 16} pack point={point} glow={glow} breathe={breathe} />

          {/* tiang di latar depan */}
          {[0, 1, 2].map((i) => {
            const x = ((((i * 1500 - dist * 2.2) % 4500) + 4500) % 4500) - 600;
            return <rect key={i} x={x} y={0} width={50} height={H} fill="#010206" />;
          })}
        </svg>

        {/* kertas beterbangan */}
        {Array.from({length: 12}).map((_, i) => {
          const sp = 6 + rand(i * 3) * 9;
          const x = ((((rand(i) * W * 2 - frame * sp) % (W * 1.5)) + W * 1.5) % (W * 1.5)) - 200;
          const y = 600 + rand(i * 5) * 300 + Math.sin(frame * 0.1 + i) * 30;
          return (
            <div
              key={i}
              style={{
                position: 'absolute',
                left: x,
                top: y,
                width: 14,
                height: 18,
                background: 'rgba(220,230,255,0.5)',
                transform: `rotate(${frame * (3 + i)}deg)`,
              }}
            />
          );
        })}

        <Fog y={700} opacity={0.6} speed={1.2} />
        <Particles count={70} color="#a9c7ff" seed={9} speed={0.3} size={2} />
      </div>

      {/* HUD scanning */}
      {CARDS.map((c, i) => {
        const l = frame - c.from;
        const o = l < 0 || l > 44 ? 0 : Math.min(ramp(l, 0, 8), 1 - ramp(l, 36, 44));
        if (o <= 0) return null;
        const typed = c.title.slice(0, Math.floor(ramp(l, 2, 16, lin) * c.title.length));
        return (
          <div
            key={i}
            style={{
              position: 'absolute',
              left: 140,
              top: 130,
              opacity: o,
              transform: `translateX(${(1 - ramp(l, 0, 10)) * -40}px)`,
            }}
          >
            <div style={{borderLeft: `4px solid ${C.orange}`, padding: '10px 24px', background: 'rgba(4,10,24,0.55)'}}>
              <div style={{fontFamily: MONO, fontSize: 20, color: C.orange, letterSpacing: 6}}>SCANNING · 0{i + 1}/03</div>
              <div style={{fontFamily: SANS, fontWeight: 800, fontSize: 40, color: C.white, letterSpacing: 6}}>{typed}</div>
              <div style={{fontFamily: MONO, fontSize: 20, color: 'rgba(160,200,255,0.85)', letterSpacing: 3}}>{c.sub}</div>
            </div>
          </div>
        );
      })}

      {/* subtitle dialog */}
      {SUBS.map((s, i) => {
        const o = Math.min(ramp(frame, s.from, s.from + 6), 1 - ramp(frame, s.to - 6, s.to));
        if (o <= 0) return null;
        return (
          <div
            key={i}
            style={{
              position: 'absolute',
              left: 0,
              right: 0,
              bottom: 124,
              textAlign: 'center',
              fontFamily: SANS,
              fontStyle: 'italic',
              fontSize: 38,
              color: C.white,
              opacity: o,
              textShadow: '0 2px 12px rgba(0,0,0,0.9)',
            }}
          >
            {s.t}
          </div>
        );
      })}
    </AbsoluteFill>
  );
};
