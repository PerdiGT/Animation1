import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame} from 'remotion';

export const FPS = 30;
export const W = 1920;
export const H = 1080;
export const TOTAL = 600;
export const OVERLAP = 12;

export const C = {
  black: '#010206',
  navy: '#061226',
  deep: '#0a1d3d',
  blue: '#1c4f9c',
  ice: '#8fc4ff',
  orange: '#ff8a2a',
  amber: '#ffb25e',
  white: '#eef4ff',
};

export const SANS = '"Helvetica Neue", Helvetica, Arial, sans-serif';
export const MONO = '"Courier New", Courier, monospace';

export const rand = (n: number): number => {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453123;
  return x - Math.floor(x);
};
export const clamp = (v: number, a = 0, b = 1): number => Math.min(b, Math.max(a, v));
export const lin = (t: number): number => t;
export const easeOut = Easing.bezier(0.16, 1, 0.3, 1);
export const easeInOut = Easing.bezier(0.65, 0, 0.35, 1);

export const ramp = (
  frame: number,
  from: number,
  to: number,
  easing: (t: number) => number = easeOut
): number =>
  interpolate(frame, [from, to], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing,
  });

export const fmt = (n: number): string =>
  Math.round(n)
    .toString()
    .replace(/\B(?=(\d{3})+(?!\d))/g, ',');

/* ---------- Transisi antar scene ---------- */
export const SceneFade: React.FC<{duration: number; children: React.ReactNode}> = ({
  duration,
  children,
}) => {
  const frame = useCurrentFrame();
  const opacity = interpolate(frame, [0, 12, duration - 12, duration], [0, 1, 1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  return <AbsoluteFill style={{opacity, backgroundColor: C.black}}>{children}</AbsoluteFill>;
};

/* ---------- Efek global ---------- */
export const Vignette: React.FC<{strength?: number}> = ({strength = 0.85}) => (
  <AbsoluteFill
    style={{
      background: `radial-gradient(ellipse at center, rgba(0,0,0,0) 45%, rgba(0,0,0,${strength}) 100%)`,
      pointerEvents: 'none',
    }}
  />
);

export const Grain: React.FC<{opacity?: number}> = ({opacity = 0.09}) => {
  const frame = useCurrentFrame();
  const s = frame % 6;
  return (
    <AbsoluteFill style={{mixBlendMode: 'overlay', opacity, pointerEvents: 'none'}}>
      <svg width="100%" height="100%" viewBox="0 0 480 270" preserveAspectRatio="none">
        <filter id={`grain${s}`}>
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed={s} stitchTiles="stitch" />
          <feColorMatrix type="saturate" values="0" />
        </filter>
        <rect width="480" height="270" filter={`url(#grain${s})`} />
      </svg>
    </AbsoluteFill>
  );
};

/* ---------- Bintang ---------- */
export const Stars: React.FC<{count?: number; seed?: number; maxY?: number; drift?: number}> = ({
  count = 160,
  seed = 3,
  maxY = H,
  drift = 0.05,
}) => {
  const frame = useCurrentFrame();
  return (
    <svg
      width={W}
      height={H}
      viewBox={`0 0 ${W} ${H}`}
      style={{position: 'absolute', left: 0, top: 0}}
    >
      {Array.from({length: count}).map((_, i) => {
        const x = (rand(seed + i * 1.7) * W - frame * drift * (0.3 + rand(seed + i)) + W) % W;
        const y = rand(seed * 2 + i * 2.3) * maxY;
        const r = 0.6 + rand(seed + i * 5.1) * 1.4;
        const tw = 0.4 + 0.6 * Math.abs(Math.sin(frame * 0.04 + i));
        return <circle key={i} cx={x} cy={y} r={r} fill="#cfe2ff" opacity={tw * 0.9} />;
      })}
    </svg>
  );
};

/* ---------- Partikel melayang ---------- */
export const Particles: React.FC<{
  count?: number;
  color?: string;
  seed?: number;
  speed?: number;
  size?: number;
  drift?: number;
}> = ({count = 60, color = C.orange, seed = 1, speed = 0.4, size = 3, drift = 40}) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      {Array.from({length: count}).map((_, i) => {
        const r1 = rand(seed * 100 + i);
        const r2 = rand(seed * 200 + i * 3);
        const r3 = rand(seed * 300 + i * 7);
        const y = (((r2 * H - frame * speed * (0.4 + r3)) % H) + H) % H;
        const x = r1 * W + Math.sin(frame * 0.02 + i) * drift;
        const tw = 0.35 + 0.65 * Math.abs(Math.sin(frame * 0.05 + i * 2.1));
        const s = size * (0.5 + r3 * 1.4);
        return (
          <div
            key={i}
            style={{
              position: 'absolute',
              left: x,
              top: y,
              width: s,
              height: s,
              borderRadius: '50%',
              background: color,
              opacity: tw * 0.8,
              boxShadow: `0 0 ${s * 4}px ${color}`,
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};

/* ---------- Kabut volumetrik ---------- */
export const Fog: React.FC<{
  y?: number;
  opacity?: number;
  color?: string;
  speed?: number;
  height?: number;
}> = ({y = 700, opacity = 0.5, color = '90,140,220', speed = 0.6, height = 420}) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{pointerEvents: 'none', overflow: 'hidden'}}>
      {[0, 1, 2, 3, 4].map((i) => {
        const x = ((i * 640 + frame * speed * (1 + i * 0.3)) % 3200) - 700;
        const yy = y + Math.sin(frame * 0.015 + i * 2) * 30 + (i % 2) * 50 - 100;
        return (
          <div
            key={i}
            style={{
              position: 'absolute',
              left: x,
              top: yy,
              width: 1300,
              height,
              background: `radial-gradient(ellipse at center, rgba(${color},${0.32 * opacity}) 0%, rgba(${color},0) 68%)`,
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};

/* ---------- Sinar cahaya (god rays) ---------- */
export const GodRays: React.FC<{
  x: number;
  y: number;
  dir?: number;
  spread?: number;
  n?: number;
  color?: string;
  opacity?: number;
  length?: number;
}> = ({x, y, dir = 180, spread = 70, n = 7, color = '255,160,80', opacity = 0.5, length = 1400}) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{pointerEvents: 'none', mixBlendMode: 'screen'}}>
      {Array.from({length: n}).map((_, i) => {
        const a = dir + (i - (n - 1) / 2) * (spread / Math.max(1, n - 1));
        const w = 90 + rand(i * 3.7 + 1) * 160;
        const o = opacity * (0.4 + 0.6 * Math.abs(Math.sin(frame * 0.02 + i * 1.7)));
        return (
          <div
            key={i}
            style={{
              position: 'absolute',
              left: x - w / 2,
              top: y,
              width: w,
              height: length,
              transformOrigin: '50% 0%',
              transform: `rotate(${a}deg)`,
              background: `linear-gradient(to bottom, rgba(${color},${o}), rgba(${color},0))`,
              filter: 'blur(16px)',
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};

/* ---------- Skyline kota (siluet) ---------- */
export const Skyline: React.FC<{
  seed: number;
  baseY: number;
  minH: number;
  maxH: number;
  fill: string;
  lit?: number;
  litColor?: string;
  width?: number;
  x?: number;
}> = ({seed, baseY, minH, maxH, fill, lit = 0.04, litColor = C.amber, width = 2700, x = 0}) => {
  const items: React.ReactNode[] = [];
  let cx = 0;
  let i = 0;
  while (cx < width) {
    const bw = 70 + rand(seed + i) * 130;
    const bh = minH + rand(seed + i * 3.3) * (maxH - minH);
    items.push(<rect key={`b${i}`} x={cx} y={baseY - bh} width={bw} height={bh + 400} fill={fill} />);
    if (rand(seed + i * 7) < 0.25) {
      items.push(
        <rect key={`a${i}`} x={cx + bw / 2} y={baseY - bh - 42} width={3} height={42} fill={fill} />
      );
    }
    const cols = Math.floor((bw - 12) / 22);
    const rows = Math.floor(bh / 30);
    for (let r = 1; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        if (rand(seed * 7 + i * 101 + r * 13 + c * 1.7) < lit) {
          items.push(
            <rect
              key={`w${i}-${r}-${c}`}
              x={cx + 8 + c * 22}
              y={baseY - bh + r * 30}
              width={8}
              height={12}
              fill={litColor}
              opacity={0.85}
            />
          );
        }
      }
    }
    cx += bw + rand(seed + i * 5.1) * 14;
    i++;
  }
  return (
    <svg
      width={width}
      height={H}
      viewBox={`0 0 ${width} ${H}`}
      style={{position: 'absolute', left: x, top: 0}}
    >
      {items}
    </svg>
  );
};

/* ---------- Teks per huruf ---------- */
export const SplitText: React.FC<{
  text: string;
  start: number;
  size: number;
  spacing?: number;
  stagger?: number;
  color?: string;
  weight?: number;
  glow?: string;
}> = ({text, start, size, spacing = 0.15, stagger = 2.5, color = C.white, weight = 800, glow = C.orange}) => {
  const frame = useCurrentFrame();
  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'center',
        whiteSpace: 'pre',
        fontFamily: SANS,
        fontWeight: weight,
        fontSize: size,
        letterSpacing: size * spacing,
        color,
      }}
    >
      {text.split('').map((ch, i) => {
        const p = ramp(frame, start + i * stagger, start + i * stagger + 18);
        return (
          <span
            key={i}
            style={{
              display: 'inline-block',
              opacity: p,
              transform: `translateY(${(1 - p) * 40}px) scale(${1 + (1 - p) * 0.3})`,
              filter: `blur(${(1 - p) * 12}px)`,
              textShadow: `0 0 ${30 * p}px ${glow}55`,
            }}
          >
            {ch}
          </span>
        );
      })}
    </div>
  );
};

/* ---------- Siluet manusia (SVG, bisa jalan / berdiri / menunjuk) ---------- */
type PersonProps = {
  x: number;
  y: number;
  scale?: number;
  view?: 'back' | 'side';
  flip?: boolean;
  walk?: number;
  phase?: number;
  head?: number;
  point?: number;
  hood?: boolean;
  pack?: boolean;
  color?: string;
  glow?: string;
  breathe?: number;
};

export const Person: React.FC<PersonProps> = ({
  x,
  y,
  scale = 1,
  view = 'back',
  flip = false,
  walk = 0,
  phase = 0,
  head = 0,
  point = 0,
  hood = false,
  pack = false,
  color = '#02040a',
  glow = 'rgba(255,138,42,0.5)',
  breathe = 0,
}) => {
  const side = view === 'side';
  const hipX = side ? 0 : 8;
  const shX = side ? 0 : 19;
  const swingA = Math.sin(phase) * 28 * walk;
  const swingB = Math.sin(phase + Math.PI) * 28 * walk;
  const kneeA = Math.max(0, -Math.cos(phase)) * 40 * walk;
  const kneeB = Math.max(0, Math.cos(phase)) * 40 * walk;
  const bob = -Math.abs(Math.sin(phase)) * 4 * walk;
  const baseA = side ? -swingA * 0.9 : 5;
  const baseB = side ? -swingB * 0.9 : -5;
  const armB = baseB * (1 - point) - 145 * point;
  const elbowA = side ? -(14 + Math.max(0, -baseA) * 0.9) : 8;
  const elbowB = (side ? -(14 + Math.max(0, -baseB) * 0.9) : -8) * (1 - point);
  const sc = flip ? -scale : scale;
  const st = {stroke: color, strokeLinecap: 'round' as const, fill: 'none'};

  return (
    <g
      transform={`translate(${x} ${y}) scale(${sc} ${scale})`}
      style={{filter: `drop-shadow(4px -2px 8px ${glow})`}}
    >
      <ellipse cx={0} cy={3} rx={40} ry={6} fill="#000" opacity={0.45} />
      <g transform={`translate(0 ${bob})`}>
        {/* kaki */}
        <g transform={`translate(${-hipX} -95) rotate(${swingA})`}>
          <line x1={0} y1={0} x2={0} y2={48} strokeWidth={15} {...st} />
          <g transform={`translate(0 48) rotate(${kneeA})`}>
            <line x1={0} y1={0} x2={0} y2={46} strokeWidth={12} {...st} />
            <rect x={side ? -5 : -8} y={42} width={side ? 22 : 16} height={9} rx={4} fill={color} />
          </g>
        </g>
        <g transform={`translate(${hipX} -95) rotate(${swingB})`}>
          <line x1={0} y1={0} x2={0} y2={48} strokeWidth={15} {...st} />
          <g transform={`translate(0 48) rotate(${kneeB})`}>
            <line x1={0} y1={0} x2={0} y2={46} strokeWidth={12} {...st} />
            <rect x={side ? -5 : -8} y={42} width={side ? 22 : 16} height={9} rx={4} fill={color} />
          </g>
        </g>
        {/* tas */}
        {pack && side && <rect x={-27} y={-152} width={16} height={46} rx={6} fill={color} />}
        {pack && !side && <rect x={-15} y={-150} width={30} height={46} rx={8} fill={color} />}
        {/* badan */}
        <g transform={`translate(0 -95) scale(1 ${1 + breathe})`}>
          <path
            d={
              side
                ? 'M-12 -2 L-13 -58 Q-12 -66 0 -67 Q12 -66 13 -58 L12 -2 Z'
                : 'M-17 -1 L-22 -56 Q-21 -64 -12 -66 L12 -66 Q21 -64 22 -56 L17 -1 Z'
            }
            fill={color}
          />
        </g>
        {/* lengan */}
        <g transform={`translate(${-shX} -151) rotate(${baseA})`}>
          <line x1={0} y1={0} x2={0} y2={36} strokeWidth={10} {...st} />
          <g transform={`translate(0 36) rotate(${elbowA})`}>
            <line x1={0} y1={0} x2={0} y2={34} strokeWidth={9} {...st} />
          </g>
        </g>
        <g transform={`translate(${shX} -151) rotate(${armB})`}>
          <line x1={0} y1={0} x2={0} y2={36} strokeWidth={10} {...st} />
          <g transform={`translate(0 36) rotate(${elbowB})`}>
            <line x1={0} y1={0} x2={0} y2={34} strokeWidth={9} {...st} />
          </g>
        </g>
        {/* leher & kepala */}
        <rect x={-4.5} y={-168} width={9} height={14} fill={color} />
        <g transform={`translate(0 -160) rotate(${head})`}>
          <circle cx={side ? 3 : 0} cy={-12} r={12} fill={color} />
          {hood && <ellipse cx={side ? -5 : 0} cy={-11} rx={side ? 13 : 15.5} ry={15.5} fill={color} />}
        </g>
      </g>
    </g>
  );
};
