import React from 'react';
import {AbsoluteFill, Sequence, useCurrentFrame} from 'remotion';
import {C, Grain, OVERLAP, SceneFade, Vignette, ramp} from './components';
import {Scene1Earth} from './scenes/Scene1Earth';
import {Scene2Street} from './scenes/Scene2Street';
import {Scene3Reveal} from './scenes/Scene3Reveal';
import {Scene4Explore} from './scenes/Scene4Explore';
import {Scene5Cliffhanger} from './scenes/Scene5Cliffhanger';

const Bars: React.FC = () => {
  const frame = useCurrentFrame();
  const h = 96 + (1 - ramp(frame, 0, 30)) * 70;
  return (
    <>
      <div style={{position: 'absolute', left: 0, right: 0, top: 0, height: h, background: '#000'}} />
      <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: h, background: '#000'}} />
    </>
  );
};

export const MainVideo: React.FC = () => {
  return (
    <AbsoluteFill style={{backgroundColor: C.black}}>
      <Sequence from={0} durationInFrames={120 + OVERLAP}>
        <SceneFade duration={120 + OVERLAP}>
          <Scene1Earth />
        </SceneFade>
      </Sequence>

      <Sequence from={120} durationInFrames={120 + OVERLAP}>
        <SceneFade duration={120 + OVERLAP}>
          <Scene2Street />
        </SceneFade>
      </Sequence>

      <Sequence from={240} durationInFrames={120 + OVERLAP}>
        <SceneFade duration={120 + OVERLAP}>
          <Scene3Reveal />
        </SceneFade>
      </Sequence>

      <Sequence from={360} durationInFrames={150 + OVERLAP}>
        <SceneFade duration={150 + OVERLAP}>
          <Scene4Explore />
        </SceneFade>
      </Sequence>

      <Sequence from={510} durationInFrames={90}>
        <SceneFade duration={90}>
          <Scene5Cliffhanger />
        </SceneFade>
      </Sequence>

      <Grain />
      <Vignette />
      <Bars />
    </AbsoluteFill>
  );
};
