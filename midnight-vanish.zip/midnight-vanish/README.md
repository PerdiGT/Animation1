# MIDNIGHT: The Vanishing (Remotion)

1080p, 30 FPS, 20 detik.

## Jalankan
```bash
npm install
sudo apt-get update && sudo apt-get install -y libnss3 libdbus-1-3 libatk1.0-0 libatk-bridge2.0-0 libgbm-dev libasound2 libxrandr2 libxkbcommon-x11-0 libxfixes3 libxcomposite1 libxdamage1 libcups2 libpango-1.0-0 libcairo2
npm run dev          # preview (port 3000)
npm run render:test  # render tes 50%
npm run render       # render final -> out/midnight-vanish.mp4
```
Kalau `libasound2` error, ganti dengan `libasound2t64`.
